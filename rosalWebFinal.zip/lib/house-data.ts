export interface HouseConfig {
  name: string
  description: string
  maxGuests: number
  location: string
  pricing: {
    low: number
    medium: number
    high: number
    holyWeek: number
    summer: number
    winter: number
    springHigh: number
    springLow: number
  }
  contact: {
    phone: string
    email: string
    whatsapp: string
  }
}

export const houseConfig: HouseConfig = {
  name: "Casa Islas Rio Miño",
  description: "Una escapada perfecta en el corazón de Galicia",
  maxGuests: 8,
  location: "Rosal, Galicia",
  pricing: {
    low: 300,
    medium: 350,
    high: 547,
    holyWeek: 547,
    summer: 547,
    winter: 547,
    springHigh: 350,
    springLow: 300,
  },
  contact: {
    phone: "670 809 429",
    email: "info@islasriomino.com",
    whatsapp: "34670809429",
  },
}

export const houseData = {
  name: "Casa Islas Rio Miño",
  description: "Una escapada perfecta en el corazón de Galicia",
  location: "Rosal, Galicia",
  capacity: 8,
  bedrooms: 4,
  bathrooms: 3,
  pricePerNight: 150,
  address: "Rua Santa Ruíz (cumieira) San Miguel de Tabagón, 36370 Rosal, España",
  email: "info@islasriomino.com",
  phoneJavier: "670 809 429",
  phoneMarta: "677 411 832",
  phone: "670 809 429",
  whatsapp: "34670809429",
  amenities: [
    "WiFi gratuito",
    "Piscina privada",
    "Jardín con barbacoa",
    "Cocina completamente equipada",
    "Aire acondicionado",
    "Calefacción",
    "Aparcamiento gratuito",
    "Vistas al río",
  ],
}

// Función para obtener el precio según la fecha (temporada)
export const getPriceForDate = (date: Date): number => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1 // 1-12
  const day = date.getDate()

  // Helper function to get Easter date for a given year
  const getEasterDate = (year: number): Date => {
    const f = Math.floor
    const G = year % 19
    const C = f(year / 100)
    const H = (C - f(C / 4) - f((8 * C + 13) / 25) + 19 * G + 15) % 30
    const I = H - f(H / 28) * (1 - f(29 / (H + 1)) * f((21 - G) / 11))
    const J = (year + f(year / 4) + I + 2 - C + f(C / 4)) % 7
    const L = I - J
    const month = 3 + f((L + 40) / 44)
    const day = L + 28 - 31 * f(month / 4)
    return new Date(year, month - 1, day)
  }

  // Get Holy Week dates (Semana Santa)
  const easterDate = getEasterDate(year)
  const holyThursday = new Date(easterDate)
  holyThursday.setDate(easterDate.getDate() - 3) // Jueves Santo
  const saturdayBeforeHolyThursday = new Date(holyThursday)
  saturdayBeforeHolyThursday.setDate(holyThursday.getDate() - 5) // Sábado antes del Jueves Santo
  const easterMonday = new Date(easterDate)
  easterMonday.setDate(easterDate.getDate() + 1) // Lunes de Pascua

  const currentDate = new Date(year, month - 1, day)

  // Semana Santa (Holy Week): €547/night
  if (currentDate >= saturdayBeforeHolyThursday && currentDate <= easterMonday) {
    return houseConfig.pricing.holyWeek
  }

  // 27 junio - 30 agosto: €547/night
  if ((month === 6 && day >= 27) || month === 7 || (month === 8 && day <= 30)) {
    return houseConfig.pricing.summer
  }

  // 20 diciembre - 7 enero: €547/night
  if ((month === 12 && day >= 20) || (month === 1 && day <= 7)) {
    return houseConfig.pricing.winter
  }

  // 30 mayo - 26 junio: €350/night
  if ((month === 5 && day >= 30) || (month === 6 && day <= 26)) {
    return houseConfig.pricing.springHigh
  }

  // Resto del año: €300/night
  // (1 septiembre - 20 diciembre, 7 enero - sábado antes de Semana Santa, después de Semana Santa - 30 mayo)
  return houseConfig.pricing.springLow
}

export const galleryPhotos = [
  {
    src: "/photos/fachada-noche.jpg",
    alt: "Fachada principal de Casa Islas Rio Miño iluminada de noche",
  },
  {
    src: "/photos/fachada-piscina-noche.jpg",
    alt: "Vista completa de la casa con piscina iluminada al anochecer",
  },
  {
    src: "/photos/fachada-completa-noche.jpg",
    alt: "Fachada completa de la casa al atardecer con jardín",
  },
  {
    src: "/photos/fachada-dia-otono.jpg",
    alt: "Fachada de la casa en otoño con hermoso árbol colorido",
  },
  {
    src: "/photos/piscina-vistas.jpg",
    alt: "Piscina con vistas panorámicas al atardecer",
  },
  {
    src: "/photos/salon-chimenea.jpg",
    alt: "Salón principal con chimenea y vistas al jardín",
  },
  {
    src: "/photos/salon-vistas-piscina.jpg",
    alt: "Salón con grandes ventanales y vistas a la piscina",
  },
  {
    src: "/photos/salon-pared-gris.jpg",
    alt: "Salón con pared de acento gris y decoración artística",
  },
  {
    src: "/photos/comedor-jardin.jpg",
    alt: "Comedor con acceso directo al jardín y biblioteca",
  },
  {
    src: "/photos/comedor-ventana.jpg",
    alt: "Comedor con mesa redonda y vistas a la montaña",
  },
  {
    src: "/photos/cena-exterior-piscina.jpg",
    alt: "Cena al aire libre junto a la piscina iluminada",
  },
  {
    src: "/photos/terraza-vistas.jpg",
    alt: "Terraza con comedor y vistas panorámicas a las montañas",
  },
  {
    src: "/photos/cocina-moderna.jpg",
    alt: "Cocina moderna totalmente equipada con acceso al jardín",
  },
  {
    src: "/photos/cocina-completa.jpg",
    alt: "Vista completa de la cocina con isla central",
  },
  {
    src: "/photos/cocina-noche.jpg",
    alt: "Vista de la cocina iluminada desde el exterior",
  },
  {
    src: "/photos/dormitorio-vistas.jpg",
    alt: "Dormitorio con camas individuales y vistas a la montaña",
  },
  {
    src: "/photos/dormitorio-vistas-principal.jpg",
    alt: "Dormitorio principal con gran ventanal y vistas al paisaje",
  },
  {
    src: "/photos/dormitorio-principal.jpg",
    alt: "Dormitorio principal con armarios empotrados",
  },
  {
    src: "/photos/dormitorio-biblioteca.jpg",
    alt: "Dormitorio con biblioteca y zona de descanso",
  },
  {
    src: "/photos/dormitorio-arte.jpg",
    alt: "Dormitorio con sofá cama y arte colorido",
  },
  {
    src: "/photos/bano-suite.jpg",
    alt: "Baño moderno en suite con ducha",
  },
  {
    src: "/photos/rincon-lectura.jpg",
    alt: "Acogedor rincón de lectura con sillón amarillo",
  },
  {
    src: "/photos/escalera-rincon.jpg",
    alt: "Escalera que conduce al rincón de lectura",
  },
  {
    src: "/photos/ventanas-noche.jpg",
    alt: "Vista nocturna de las ventanas iluminadas desde el jardín",
  },
]
