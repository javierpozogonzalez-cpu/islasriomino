// Simulación de base de datos (en producción usarías una base de datos real)
interface Reserva {
  id: number
  nombre: string
  email: string
  telefono?: string
  fechaCheckin: Date
  fechaCheckout: Date
  numHuespedes: number
  precioTotal: number
  estado: "pendiente" | "confirmada" | "cancelada"
  mensaje?: string
  fechaCreacion: Date
}

interface FechaBloqueada {
  id: number
  fechaInicio: Date
  fechaFin: Date
  motivo: string
}

// Simulación de datos (en producción esto vendría de una base de datos real)
const reservas: Reserva[] = [
  {
    id: 1,
    nombre: "Juan Pérez",
    email: "juan@email.com",
    telefono: "+34123456789",
    fechaCheckin: new Date("2024-02-15"),
    fechaCheckout: new Date("2024-02-18"),
    numHuespedes: 4,
    precioTotal: 450,
    estado: "confirmada",
    mensaje: "Reserva para familia con niños",
    fechaCreacion: new Date(),
  },
  {
    id: 2,
    nombre: "María García",
    email: "maria@email.com",
    telefono: "+34987654321",
    fechaCheckin: new Date("2024-03-20"),
    fechaCheckout: new Date("2024-03-25"),
    numHuespedes: 6,
    precioTotal: 750,
    estado: "confirmada",
    mensaje: "Celebración aniversario",
    fechaCreacion: new Date(),
  },
]

const fechasBloqueadas: FechaBloqueada[] = [
  {
    id: 1,
    fechaInicio: new Date("2024-01-15"),
    fechaFin: new Date("2024-01-20"),
    motivo: "Mantenimiento piscina",
  },
]

// Función para verificar si una fecha está ocupada
export const isDateOccupied = (date: Date): boolean => {
  const dateStr = date.toISOString().split("T")[0]

  // Verificar reservas confirmadas
  const isReserved = reservas.some((reserva) => {
    if (reserva.estado !== "confirmada") return false

    const checkin = reserva.fechaCheckin.toISOString().split("T")[0]
    const checkout = reserva.fechaCheckout.toISOString().split("T")[0]

    return dateStr >= checkin && dateStr < checkout
  })

  // Verificar fechas bloqueadas
  const isBlocked = fechasBloqueadas.some((bloqueo) => {
    const inicio = bloqueo.fechaInicio.toISOString().split("T")[0]
    const fin = bloqueo.fechaFin.toISOString().split("T")[0]

    return dateStr >= inicio && dateStr <= fin
  })

  return isReserved || isBlocked
}

// Función para verificar disponibilidad en un rango de fechas
export const isRangeAvailable = (checkin: Date, checkout: Date): boolean => {
  const currentDate = new Date(checkin)

  while (currentDate < checkout) {
    if (isDateOccupied(currentDate)) {
      return false
    }
    currentDate.setDate(currentDate.getDate() + 1)
  }

  return true
}

// Función para crear una nueva reserva
export const createReservation = async (
  reservaData: Omit<Reserva, "id" | "fechaCreacion">,
): Promise<{ success: boolean; message: string; reservaId?: number }> => {
  try {
    // Verificar disponibilidad
    if (!isRangeAvailable(reservaData.fechaCheckin, reservaData.fechaCheckout)) {
      return {
        success: false,
        message: "Las fechas seleccionadas no están disponibles",
      }
    }

    // Crear nueva reserva
    const nuevaReserva: Reserva = {
      ...reservaData,
      id: reservas.length + 1,
      fechaCreacion: new Date(),
    }

    reservas.push(nuevaReserva)

    return {
      success: true,
      message: "Reserva creada exitosamente",
      reservaId: nuevaReserva.id,
    }
  } catch (error) {
    return {
      success: false,
      message: "Error al crear la reserva",
    }
  }
}

// Función para obtener todas las reservas
export const getReservations = (): Reserva[] => {
  return reservas
}

// Función para actualizar estado de reserva
export const updateReservationStatus = (id: number, estado: "pendiente" | "confirmada" | "cancelada"): boolean => {
  const reserva = reservas.find((r) => r.id === id)
  if (reserva) {
    reserva.estado = estado
    return true
  }
  return false
}

// Función para obtener reservas por email
export const getReservationsByEmail = (email: string): Reserva[] => {
  return reservas.filter((r) => r.email === email)
}
