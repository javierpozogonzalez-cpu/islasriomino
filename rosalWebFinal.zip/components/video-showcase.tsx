"use client"

import { useState } from "react"
import { Play, X } from "lucide-react"
import Image from "next/image"

export function VideoShowcase() {
  const [isPlaying, setIsPlaying] = useState(false)

  return (
    <section className="relative py-20 bg-gradient-to-b from-gray-900 to-gray-800 overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-orange-600/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-orange-600/10 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Vista Aérea - Tour en Dron</h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">Descubre la casa y sus alrededores desde el cielo</p>
        </div>

        <div className="max-w-5xl mx-auto">
          {/* Video Container */}
          <div className="relative group">
            {!isPlaying ? (
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                {/* Thumbnail */}
                <div className="relative aspect-video">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/7B2A8FE7-58AD-4F8B-B2B5-91EA31FC17CD_1_102_o-Jxf4DdVNDg8dcarMC7oYj6d9xGWQL8.jpeg"
                    alt="Vista aérea de Casa Islas Rio Miño"
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-black/30 group-hover:bg-black/20 transition-colors"></div>
                </div>

                {/* Play Button */}
                <button
                  onClick={() => setIsPlaying(true)}
                  className="absolute inset-0 flex items-center justify-center group"
                  aria-label="Reproducir video"
                >
                  <div className="w-24 h-24 bg-orange-600 rounded-full flex items-center justify-center shadow-2xl group-hover:scale-110 group-hover:bg-orange-500 transition-all duration-300">
                    <Play className="w-10 h-10 text-white ml-1" fill="white" />
                  </div>
                </button>

                {/* Decorative corners */}
                <div className="absolute top-4 left-4 w-12 h-12 border-t-4 border-l-4 border-orange-600 rounded-tl-lg"></div>
                <div className="absolute top-4 right-4 w-12 h-12 border-t-4 border-r-4 border-orange-600 rounded-tr-lg"></div>
                <div className="absolute bottom-4 left-4 w-12 h-12 border-b-4 border-l-4 border-orange-600 rounded-bl-lg"></div>
                <div className="absolute bottom-4 right-4 w-12 h-12 border-b-4 border-r-4 border-orange-600 rounded-br-lg"></div>
              </div>
            ) : (
              <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-black">
                {/* Video Player */}
                <div className="relative aspect-video">
                  <iframe
                    src="https://drive.google.com/file/d/1D0lJOX6CvzaPdspGNY5-hxvOtgeTkPrw/preview"
                    className="w-full h-full"
                    allow="autoplay"
                    allowFullScreen
                  ></iframe>
                </div>

                {/* Close Button */}
                <button
                  onClick={() => setIsPlaying(false)}
                  className="absolute top-4 right-4 w-12 h-12 bg-black/70 hover:bg-black/90 rounded-full flex items-center justify-center transition-colors z-20"
                  aria-label="Cerrar video"
                >
                  <X className="w-6 h-6 text-white" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
