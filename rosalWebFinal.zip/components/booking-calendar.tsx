"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight, MessageCircle, CalendarIcon } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { houseData, getPriceForDate } from "@/lib/house-data"

const months = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Julio",
  "Agosto",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre",
]

const daysOfWeek = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"]

export function BookingCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [checkIn, setCheckIn] = useState<Date | null>(null)
  const [checkOut, setCheckOut] = useState<Date | null>(null)
  const [guests, setGuests] = useState(2)
  const [nombre, setNombre] = useState("")
  const [email, setEmail] = useState("")
  const [telefono, setTelefono] = useState("")
  const [mensaje, setMensaje] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [occupiedDates, setOccupiedDates] = useState<Set<string>>(new Set())

  const year = currentDate.getFullYear()
  const month = currentDate.getMonth()

  // Cargar fechas ocupadas al cambiar el mes
  useEffect(() => {
    const loadOccupiedDates = async () => {
      const firstDay = new Date(year, month, 1)
      const lastDay = new Date(year, month + 1, 0)
      const dates: string[] = []

      for (let d = new Date(firstDay); d <= lastDay; d.setDate(d.getDate() + 1)) {
        dates.push(d.toISOString().split("T")[0])
      }

      try {
        const response = await fetch("/api/disponibilidad", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ fechas: dates }),
        })

        if (response.ok) {
          const data = await response.json()
          const occupied = new Set(data.data.filter((item: any) => item.ocupada).map((item: any) => item.fecha))
          setOccupiedDates(occupied)
        }
      } catch (error) {
        console.error("Error loading occupied dates:", error)
      }
    }

    loadOccupiedDates()
  }, [year, month])

  const firstDayOfMonth = new Date(year, month, 1)
  const lastDayOfMonth = new Date(year, month + 1, 0)
  const firstDayWeekday = firstDayOfMonth.getDay()
  const daysInMonth = lastDayOfMonth.getDate()

  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1))
  }

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1))
  }

  const handleDateClick = (day: number) => {
    const clickedDate = new Date(year, month, day)
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    const dateStr = clickedDate.toISOString().split("T")[0]

    if (clickedDate < today || occupiedDates.has(dateStr)) return

    if (!checkIn || (checkIn && checkOut)) {
      setCheckIn(clickedDate)
      setCheckOut(null)
    } else if (clickedDate > checkIn) {
      // Verificar que no hay fechas ocupadas en el rango
      const rangeHasOccupied = hasOccupiedDatesInRange(checkIn, clickedDate)
      if (!rangeHasOccupied) {
        setCheckOut(clickedDate)
      } else {
        // Si hay fechas ocupadas, reiniciar selección
        setCheckIn(clickedDate)
        setCheckOut(null)
      }
    } else {
      setCheckIn(clickedDate)
      setCheckOut(null)
    }
  }

  const hasOccupiedDatesInRange = (start: Date, end: Date): boolean => {
    const current = new Date(start)
    current.setDate(current.getDate() + 1) // Empezar desde el día siguiente al check-in

    while (current < end) {
      const dateStr = current.toISOString().split("T")[0]
      if (occupiedDates.has(dateStr)) {
        return true
      }
      current.setDate(current.getDate() + 1)
    }
    return false
  }

  const isDateInRange = (day: number) => {
    if (!checkIn || !checkOut) return false
    const date = new Date(year, month, day)
    return date > checkIn && date < checkOut
  }

  const isDateSelected = (day: number) => {
    const date = new Date(year, month, day)
    return (checkIn && date.getTime() === checkIn.getTime()) || (checkOut && date.getTime() === checkOut.getTime())
  }

  const isDateDisabled = (day: number) => {
    const date = new Date(year, month, day)
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const dateStr = date.toISOString().split("T")[0]

    return date < today || occupiedDates.has(dateStr)
  }

  const isDatePending = (day: number) => {
    const date = new Date(year, month, day)
    const dateStr = date.toISOString().split("T")[0]
    // For now, all occupied dates are shown as confirmed
    // In the future, you could add a "pending" status from the API
    return false
  }

  const calculateNights = () => {
    if (!checkIn || !checkOut) return 0
    const diffTime = checkOut.getTime() - checkIn.getTime()
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24))
  }

  const calculateTotalPrice = () => {
    if (!checkIn || !checkOut) return 0

    let total = 0
    const current = new Date(checkIn)

    while (current < checkOut) {
      total += getPriceForDate(current)
      current.setDate(current.getDate() + 1)
    }

    return total + 50 // Añadir tasa de limpieza
  }

  const formatDate = (date: Date | null) => {
    if (!date) return ""
    return date.toLocaleDateString("es-ES", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  const handleSubmitReservation = async () => {
    if (!checkIn || !checkOut || !nombre || !email) {
      alert("Por favor, completa todos los campos obligatorios")
      return
    }

    setIsSubmitting(true)

    try {
      const response = await fetch("/api/reservas", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nombre,
          email,
          telefono,
          fechaCheckin: checkIn.toISOString(),
          fechaCheckout: checkOut.toISOString(),
          numHuespedes: guests,
          mensaje,
        }),
      })

      const data = await response.json()

      if (data.success) {
        alert(`¡Reserva creada exitosamente! Total: ${data.data.precioTotal}€. Te contactaremos pronto para confirmar.`)

        // Limpiar formulario
        setCheckIn(null)
        setCheckOut(null)
        setNombre("")
        setEmail("")
        setTelefono("")
        setMensaje("")

        // Recargar fechas ocupadas
        const firstDay = new Date(year, month, 1)
        const lastDay = new Date(year, month + 1, 0)
        const dates: string[] = []

        for (let d = new Date(firstDay); d <= lastDay; d.setDate(d.getDate() + 1)) {
          dates.push(d.toISOString().split("T")[0])
        }

        const availabilityResponse = await fetch("/api/disponibilidad", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ fechas: dates }),
        })

        if (availabilityResponse.ok) {
          const availabilityData = await availabilityResponse.json()
          const occupied = new Set(
            availabilityData.data.filter((item: any) => item.ocupada).map((item: any) => item.fecha),
          )
          setOccupiedDates(occupied)
        }
      } else {
        alert(`Error: ${data.message}`)
      }
    } catch (error) {
      alert("Error al crear la reserva. Por favor, inténtalo de nuevo.")
      console.error("Error:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleWhatsAppBooking = () => {
    const totalPrice = calculateTotalPrice()
    const nights = calculateNights()

    let message = `🏡 *Solicitud de Reserva - ${houseData.name}*\n\n`
    message += `👤 *Datos del solicitante:*\n`
    message += `Nombre: ${nombre}\n`
    message += `Email: ${email}\n`
    if (telefono) message += `Teléfono: ${telefono}\n`
    message += `\n📅 *Detalles de la estancia:*\n`
    message += `Check-in: ${formatDate(checkIn)}\n`
    message += `Check-out: ${formatDate(checkOut)}\n`
    message += `Noches: ${nights}\n`
    message += `Huéspedes: ${guests} ${guests === 1 ? "persona" : "personas"}\n`
    message += `\n💰 *Precio total: ${totalPrice}€*\n`
    if (mensaje) {
      message += `\n📝 *Información adicional:*\n${mensaje}\n`
    }
    message += `\n¿Está disponible para estas fechas?`

    const whatsappUrl = `https://wa.me/${houseData.whatsapp}?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
  }

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Reserva tu Estancia</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Selecciona las fechas de tu estancia y completa el formulario de reserva{" "}
            <span className="text-sm italic">
              (Consulta disponibilidad - próxima actualización mostrará fechas reservadas en tiempo real)
            </span>
          </p>
        </div>

        <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-8">
          {/* Calendar */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <Button variant="outline" size="icon" onClick={prevMonth}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <CardTitle className="text-lg">
                  {months[month]} {year}
                </CardTitle>
                <Button variant="outline" size="icon" onClick={nextMonth}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-1 mb-4">
                {daysOfWeek.map((day) => (
                  <div key={day} className="text-center text-sm font-medium text-gray-500 p-2">
                    {day}
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-7 gap-1">
                {Array.from({ length: firstDayWeekday }, (_, i) => (
                  <div key={`empty-${i}`} className="p-2"></div>
                ))}

                {Array.from({ length: daysInMonth }, (_, i) => {
                  const day = i + 1
                  const disabled = isDateDisabled(day)
                  const selected = isDateSelected(day)
                  const inRange = isDateInRange(day)
                  const date = new Date(year, month, day)
                  const price = getPriceForDate(date)
                  const dateStr = date.toISOString().split("T")[0]
                  const isOccupied = occupiedDates.has(dateStr)

                  return (
                    <button
                      key={day}
                      onClick={() => handleDateClick(day)}
                      disabled={disabled}
                      className={`
                        p-2 text-sm rounded-md transition-colors relative min-h-[60px] flex flex-col justify-center
                        ${disabled && isOccupied ? "text-gray-400 cursor-not-allowed bg-red-50 border border-red-200" : ""}
                        ${disabled && !isOccupied ? "text-gray-300 cursor-not-allowed bg-gray-100" : ""}
                        ${!disabled ? "hover:bg-blue-50 cursor-pointer" : ""}
                        ${selected ? "bg-blue-600 text-white hover:bg-blue-700" : ""}
                        ${inRange && !selected ? "bg-blue-100 text-blue-900" : ""}
                      `}
                    >
                      <div className="font-medium">{day}</div>
                      {!disabled && <div className="text-xs mt-1 opacity-75">{price}€</div>}
                      {isOccupied && <div className="text-xs mt-1 font-semibold text-red-600">Reservado</div>}
                    </button>
                  )
                })}
              </div>

              <div className="mt-4 text-xs text-gray-500 space-y-1">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-50 border border-red-200 rounded"></div>
                  <span>Reservado</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-gray-100 rounded"></div>
                  <span>No disponible</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-600 rounded"></div>
                  <span>Seleccionado</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-100 rounded"></div>
                  <span>Rango seleccionado</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Booking Form */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalendarIcon className="h-5 w-5" />
                Formulario de Reserva
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Fechas seleccionadas */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Check-in</Label>
                  <div className="p-3 border rounded-md bg-gray-50 text-sm">
                    {checkIn ? formatDate(checkIn) : "Selecciona fecha"}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Check-out</Label>
                  <div className="p-3 border rounded-md bg-gray-50 text-sm">
                    {checkOut ? formatDate(checkOut) : "Selecciona fecha"}
                  </div>
                </div>
              </div>

              {/* Huéspedes */}
              <div className="space-y-2">
                <Label htmlFor="guests">Número de huéspedes</Label>
                <select
                  id="guests"
                  value={guests}
                  onChange={(e) => setGuests(Number(e.target.value))}
                  className="w-full p-3 border rounded-md"
                >
                  {Array.from({ length: houseData.capacity }, (_, i) => (
                    <option key={i + 1} value={i + 1}>
                      {i + 1} {i + 1 === 1 ? "huésped" : "huéspedes"}
                    </option>
                  ))}
                </select>
              </div>

              {/* Datos personales */}
              <div className="space-y-2">
                <Label htmlFor="nombre">Nombre completo *</Label>
                <Input
                  id="nombre"
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                  placeholder="Tu nombre completo"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="tu@email.com"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="telefono">Teléfono</Label>
                <Input
                  id="telefono"
                  value={telefono}
                  onChange={(e) => setTelefono(e.target.value)}
                  placeholder="+34 123 456 789"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="mensaje">Mensaje adicional</Label>
                <Textarea
                  id="mensaje"
                  value={mensaje}
                  onChange={(e) => setMensaje(e.target.value)}
                  placeholder="Cuéntanos sobre tu estancia, necesidades especiales, etc."
                  rows={3}
                />
              </div>

              {/* Resumen de precio */}
              {checkIn && checkOut && (
                <div className="border-t pt-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>{calculateNights()} noches</span>
                    <span>{calculateTotalPrice() - 50}€</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Tasa de limpieza</span>
                    <span>50€</span>
                  </div>
                  <div className="flex justify-between font-semibold text-lg border-t pt-2">
                    <span>Total</span>
                    <span>{calculateTotalPrice()}€</span>
                  </div>
                </div>
              )}

              {/* Botones de acción */}
              <div className="space-y-2">
                <Button
                  className="w-full bg-green-600 hover:bg-green-700"
                  size="lg"
                  onClick={handleWhatsAppBooking}
                  disabled={!checkIn || !checkOut || !nombre || !email}
                >
                  <MessageCircle className="mr-2 h-4 w-4" />
                  Reservar por WhatsApp
                </Button>
              </div>

              <p className="text-xs text-gray-500 text-center">
                * Completa los datos y haz clic para enviar tu reserva por WhatsApp
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
