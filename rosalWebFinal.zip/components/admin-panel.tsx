"use client"

import { useState, useEffect } from "react"
import { Calendar, Users, CheckCircle, XCircle, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { getReservations, updateReservationStatus } from "@/lib/database"

interface Reserva {
  id: number
  nombre: string
  email: string
  telefono?: string
  fechaCheckin: Date
  fechaCheckout: Date
  numHuespedes: number
  precioTotal: number
  estado: "pendiente" | "confirmada" | "cancelada"
  mensaje?: string
  fechaCreacion: Date
}

export function AdminPanel() {
  const [reservas, setReservas] = useState<Reserva[]>([])
  const [filtroEstado, setFiltroEstado] = useState<"todas" | "pendiente" | "confirmada" | "cancelada">("todas")

  useEffect(() => {
    setReservas(getReservations())
  }, [])

  const handleUpdateStatus = (id: number, nuevoEstado: "pendiente" | "confirmada" | "cancelada") => {
    if (updateReservationStatus(id, nuevoEstado)) {
      setReservas(getReservations())
    }
  }

  const reservasFiltradas = filtroEstado === "todas" ? reservas : reservas.filter((r) => r.estado === filtroEstado)

  const getStatusColor = (estado: string) => {
    switch (estado) {
      case "confirmada":
        return "bg-green-100 text-green-800"
      case "pendiente":
        return "bg-yellow-100 text-yellow-800"
      case "cancelada":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (estado: string) => {
    switch (estado) {
      case "confirmada":
        return <CheckCircle className="h-4 w-4" />
      case "pendiente":
        return <Clock className="h-4 w-4" />
      case "cancelada":
        return <XCircle className="h-4 w-4" />
      default:
        return null
    }
  }

  const calcularNoches = (checkin: Date, checkout: Date) => {
    const diffTime = checkout.getTime() - checkin.getTime()
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24))
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Panel de Administración</h1>
        <p className="text-gray-600">Gestiona las reservas de Casa Islas Rio Miño</p>
      </div>

      {/* Estadísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Reservas</p>
                <p className="text-2xl font-bold text-gray-900">{reservas.length}</p>
              </div>
              <Calendar className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Confirmadas</p>
                <p className="text-2xl font-bold text-green-600">
                  {reservas.filter((r) => r.estado === "confirmada").length}
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pendientes</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {reservas.filter((r) => r.estado === "pendiente").length}
                </p>
              </div>
              <Clock className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Ingresos</p>
                <p className="text-2xl font-bold text-blue-600">
                  {reservas.filter((r) => r.estado === "confirmada").reduce((total, r) => total + r.precioTotal, 0)}€
                </p>
              </div>
              <Users className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filtros */}
      <div className="flex gap-2 mb-6">
        {["todas", "pendiente", "confirmada", "cancelada"].map((estado) => (
          <Button
            key={estado}
            variant={filtroEstado === estado ? "default" : "outline"}
            size="sm"
            onClick={() => setFiltroEstado(estado as any)}
            className="capitalize"
          >
            {estado}
          </Button>
        ))}
      </div>

      {/* Lista de Reservas */}
      <div className="space-y-4">
        {reservasFiltradas.map((reserva) => (
          <Card key={reserva.id}>
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">{reserva.nombre}</h3>
                    <Badge className={`${getStatusColor(reserva.estado)} flex items-center gap-1`}>
                      {getStatusIcon(reserva.estado)}
                      {reserva.estado}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-gray-600">
                    <div>
                      <p className="font-medium">Fechas</p>
                      <p>
                        {reserva.fechaCheckin.toLocaleDateString("es-ES")} -{" "}
                        {reserva.fechaCheckout.toLocaleDateString("es-ES")}
                      </p>
                      <p className="text-xs">({calcularNoches(reserva.fechaCheckin, reserva.fechaCheckout)} noches)</p>
                    </div>

                    <div>
                      <p className="font-medium">Contacto</p>
                      <p>{reserva.email}</p>
                      {reserva.telefono && <p>{reserva.telefono}</p>}
                    </div>

                    <div>
                      <p className="font-medium">Huéspedes</p>
                      <p>{reserva.numHuespedes} personas</p>
                    </div>

                    <div>
                      <p className="font-medium">Total</p>
                      <p className="text-lg font-bold text-green-600">{reserva.precioTotal}€</p>
                    </div>
                  </div>

                  {reserva.mensaje && (
                    <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-700">{reserva.mensaje}</p>
                    </div>
                  )}
                </div>

                {/* Acciones */}
                <div className="flex flex-col gap-2 lg:flex-row">
                  {reserva.estado === "pendiente" && (
                    <>
                      <Button
                        size="sm"
                        onClick={() => handleUpdateStatus(reserva.id, "confirmada")}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Confirmar
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleUpdateStatus(reserva.id, "cancelada")}
                        className="border-red-300 text-red-600 hover:bg-red-50"
                      >
                        <XCircle className="h-4 w-4 mr-1" />
                        Cancelar
                      </Button>
                    </>
                  )}

                  {reserva.estado === "confirmada" && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleUpdateStatus(reserva.id, "cancelada")}
                      className="border-red-300 text-red-600 hover:bg-red-50"
                    >
                      <XCircle className="h-4 w-4 mr-1" />
                      Cancelar
                    </Button>
                  )}

                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => window.open(`https://wa.me/${reserva.telefono?.replace(/\s/g, "")}`, "_blank")}
                    className="border-green-300 text-green-600 hover:bg-green-50"
                  >
                    WhatsApp
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {reservasFiltradas.length === 0 && (
        <div className="text-center py-12">
          <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No hay reservas</h3>
          <p className="text-gray-600">No se encontraron reservas con el filtro seleccionado.</p>
        </div>
      )}
    </div>
  )
}
