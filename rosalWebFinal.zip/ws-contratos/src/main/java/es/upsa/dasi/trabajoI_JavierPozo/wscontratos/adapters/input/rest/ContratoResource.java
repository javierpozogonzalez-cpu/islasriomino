package es.upsa.dasi.trabajoI_JavierPozo.wscontratos.adapters.input.rest;

import es.upsa.dasi.trabajoI_JavierPozo.domain.dtos.ContratoDto;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.ContratoNotFoundException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.mappers.Mappers;
import es.upsa.dasi.trabajoI_JavierPozo.wscontratos.application.*;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;

import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@ApplicationScoped
@Path("/contratos")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ContratoResource
{
    @Inject
    GetContratoUseCase getContratoUseCase;

    @Inject
    GetContratoByIdUseCase getContratoByIdUseCase;

    @Inject
    GetContratosByEquipoId getContratosByEquipoId;

    @Inject
    GetContratosByPersonaId getContratosByPersonaId;

    @Inject
    AddContratoUseCase addContratoUseCase;

    @Inject
    UpdateContratoUseCase updateContratoUseCase;

    @Inject
    DeleteContratoUseCase deleteContratoUseCase;

    @GET
    public Response getContratos() throws EquipoAppException
    {
        List<Contrato> contratos = getContratoUseCase.execute();

        return Response.ok()
                       .entity(new GenericEntity<List<Contrato>>(contratos) {})
                       .build();
    }

    @GET
    @Path("/{id}")
    public Response getContratoById(@PathParam("id") String id) throws EquipoAppException
    {
        Optional<Contrato> optContrato = getContratoByIdUseCase.execute(id);

        return optContrato.map(contrato -> Response.ok().entity(contrato).build())
                          .orElseThrow(() -> new ContratoNotFoundException());
    }

    @GET
    @Path("/equipos/{equipoId}")
    public Response getContratoByEquipoId(@PathParam("equipoId") String idEquipo) throws EquipoAppException
    {
        List<Contrato> contratos = getContratosByEquipoId.execute(idEquipo);

        return Response.ok()
                       .entity(new GenericEntity<List<Contrato>>(contratos) {})
                       .build();
    }

    @GET
    @Path("/personas/{personaId}")
    public Response getContratoByPersonaId(@PathParam("personaId") String idPersona) throws EquipoAppException
    {
        List<Contrato> contratos = getContratosByPersonaId.execute(idPersona);

        return Response.ok()
                       .entity(new GenericEntity<List<Contrato>>(contratos) {})
                       .build();
    }

    @POST
    public Response addContrato(ContratoDto contratoDto, @Context UriInfo uriInfo, @DefaultValue("") @HeaderParam("X-Forwarded-Prefix") String prefix) throws EquipoAppException
    {
        Contrato contrato = Mappers.toContrato(contratoDto);
        Contrato insertedContrato = addContratoUseCase.execute(contrato);

        return Response.created(createContratoURI(uriInfo, insertedContrato, prefix))
                       .entity(insertedContrato)
                       .build();
    }

    @PUT
    @Path("/{id}")
    public Response updateContrato(@PathParam("id") String id, ContratoDto contratoDto) throws EquipoAppException
    {
        Contrato contrato = Mappers.toContrato(contratoDto)
                                   .withId(id);

        Contrato updatedContrato = updateContratoUseCase.execute(contrato);

        return Response.ok()
                       .entity(updatedContrato)
                       .build();
    }

    @DELETE
    @Path("{id}")
    public Response deleteContrato(@PathParam("id") String id) throws EquipoAppException
    {
        deleteContratoUseCase.execute(id);

        return Response.noContent()
                       .build();
    }

    private URI createContratoURI(UriInfo uriInfo, Contrato contrato, String prefix)
    {
        return uriInfo.getBaseUriBuilder()
                      .path(prefix)
                      .path("/contratos/{id}")
                      .resolveTemplate("id", contrato.getId())
                      .build();
    }

}
