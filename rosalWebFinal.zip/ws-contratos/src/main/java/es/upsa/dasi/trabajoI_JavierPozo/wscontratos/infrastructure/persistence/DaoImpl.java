package es.upsa.dasi.trabajoI_JavierPozo.wscontratos.infrastructure.persistence;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Tipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.ContratoNotFoundException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.PersonaNotFoundAppException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.SQLEquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wscontratos.adapters.output.persistence.Dao;
import es.upsa.dasi.trabajoI_JavierPozo.wscontratos.domain.exceptions.FieldRequiredSQLException;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@ApplicationScoped
public class DaoImpl implements Dao
{
    @Inject
    DataSource dataSource;

    @Override
    public List<Contrato> findAll() throws EquipoAppException
    {
        final String SQL = """
                           SELECT c.id, c.id_persona, c.id_equipo, c.tipo, c.posicion
                             FROM contratos c
                           """;
        List<Contrato> contratos = new ArrayList<>();

        try (
                Connection connection = dataSource.getConnection();
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(SQL);
            )
        {
            while(resultSet.next())
            {
                contratos.add(toContrato(resultSet));
            }

            return contratos;

        } catch (SQLException sqlException)
          {
              throw manageException(sqlException);
          }
    }

    @Override
    public Optional<Contrato> findById(String id) throws EquipoAppException
    {
        final String SQL = """
                           SELECT c.id, c.id_persona, c.id_equipo, c.tipo, c.posicion
                             FROM contratos c
                            WHERE c.id = ? 
                           """;

        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SQL);
            )
        {
            preparedStatement.setString(1, id);

            try (ResultSet resultSet = preparedStatement.executeQuery())
            {
                return (!resultSet.next()) ? Optional.empty(): Optional.of(toContrato(resultSet));
            }

        } catch (SQLException sqlException)
          {
              throw manageException(sqlException);
          }
    }

    @Override
    public List<Contrato> findByEquipoId(String id) throws EquipoAppException
    {
        final String SQL = """
                           SELECT c.id, c.id_persona, c.id_equipo, c.tipo, c.posicion
                             FROM contratos c
                            WHERE c.id_equipo = ? 
                           """;
        List<Contrato> contratos = new ArrayList<>();

        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SQL);
            )
        {
            preparedStatement.setString(1, id);

            try (ResultSet resultSet = preparedStatement.executeQuery())
            {
                while (resultSet.next())
                {
                    contratos.add(toContrato(resultSet));
                }
            }

            return contratos;

        } catch (SQLException sqlException)
          {
              throw manageException(sqlException);
          }
    }

    @Override
    public List<Contrato> findByPersonaId(String id) throws EquipoAppException
    {
        final String SQL = """
                           SELECT c.id, c.id_persona, c.id_equipo, c.tipo, c.posicion
                             FROM contratos c
                            WHERE c.id_persona = ? 
                           """;
        List<Contrato> contratos = new ArrayList<>();

        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SQL);
        )
        {
            preparedStatement.setString(1, id);

            try (ResultSet resultSet = preparedStatement.executeQuery())
            {
                while (resultSet.next())
                {
                    contratos.add(toContrato(resultSet));
                }
            }

            return contratos;

        } catch (SQLException sqlException)
        {
            throw manageException(sqlException);
        }
    }

    @Override
    public Contrato insertContrato(Contrato contrato) throws EquipoAppException
    {
        final String SQL = """
                           INSERT INTO contratos(id,                       id_persona, id_equipo, tipo, posicion)
                                         VALUES (nextval('seq_contratos'), ?,          ?,         ?,    ?       )
                           """;
        final String[] fields = {"id"};

        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SQL, fields);
            )
        {
            preparedStatement.setString(1, contrato.getIdPersona());
            preparedStatement.setString(2, contrato.getIdEquipo());
            preparedStatement.setString(3, contrato.getTipo().toString());
            preparedStatement.setString(4, contrato.getPosicion());

            preparedStatement.executeUpdate();

            try (ResultSet resultSet = preparedStatement.getGeneratedKeys())
            {
                resultSet.next();
                String id = resultSet.getString(1);

                return contrato.withId(id);
            }

        } catch (SQLException sqlException)
          {
              throw manageException(sqlException);
          }
    }

    @Override
    public Optional<Contrato> updateContrato(Contrato contrato) throws EquipoAppException
    {
        final String SQL = """
                           UPDATE contratos 
                            SET id_persona = ?, 
                                id_equipo = ?, 
                                tipo = ?, 
                                posicion = ?
                            WHERE id = ?    
                           """;

        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SQL);
            )
        {
            preparedStatement.setString(1, contrato.getIdPersona());
            preparedStatement.setString(2, contrato.getIdEquipo());
            preparedStatement.setString(3, contrato.getTipo().toString());
            preparedStatement.setString(4, contrato.getPosicion().toString());
            preparedStatement.setString(5, contrato.getId());

            int count = preparedStatement.executeUpdate();

            return (count == 0) ? Optional.empty() : Optional.of(contrato);

        } catch (SQLException sqlException)
          {
              throw manageException(sqlException);
          }
    }

    @Override
    public void deleteContrato(String id) throws EquipoAppException
    {
        final String SQL = """
                           DELETE 
                             FROM contratos 
                            WHERE id = ?
                           """;

        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SQL);
            )
        {
            preparedStatement.setString(1, id);

            int count = preparedStatement.executeUpdate();

            if (count == 0) throw new ContratoNotFoundException();
        } catch (SQLException sqlException)
          {
              throw manageException(sqlException);
          }

    }

    private Contrato toContrato(ResultSet resultSet) throws SQLException
    {
        return Contrato.builder()
                       .withId(resultSet.getString(1))
                       .withIdPersona(resultSet.getString(2))
                       .withIdEquipo(resultSet.getString(3))
                       .withTipo(Tipo.valueOf(resultSet.getString(4)))
                       .withPosicion(resultSet.getString(5))
                       .build();
    }

    private EquipoAppException manageException(SQLException sqlException)
    {
        String message = sqlException.getMessage();

        if (message.contains("NN_CONTRATOS_ID_PERSONA")) return new FieldRequiredSQLException("idPersona");
        if (message.contains("NN_CONTRATOS_ID_EQUIPO")) return new FieldRequiredSQLException("idEquipo");
        if (message.contains("FK_CONTRATOS_PERSONAS")) return new PersonaNotFoundAppException();
        if (message.contains("FK_CONTRATOS_EQUIPOS")) return new EquipoAppException();

        return new SQLEquipoAppException(sqlException);
    }
}
