package es.upsa.dasi.trabajoI_JavierPozo.wscontratos.domain.exceptions;

import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

public class FieldRequiredSQLException extends EquipoAppException
{
    public FieldRequiredSQLException(String fieldName)
    {
        super("El campo " + fieldName + " es obligatorio");
    }
}
