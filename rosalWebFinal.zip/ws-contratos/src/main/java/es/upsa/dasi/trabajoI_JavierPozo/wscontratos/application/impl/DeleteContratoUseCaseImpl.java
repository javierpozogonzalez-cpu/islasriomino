package es.upsa.dasi.trabajoI_JavierPozo.wscontratos.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wscontratos.application.DeleteContratoUseCase;
import es.upsa.dasi.trabajoI_JavierPozo.wscontratos.domain.repository.Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class DeleteContratoUseCaseImpl implements DeleteContratoUseCase
{
    @Inject
    Repository repository;

    @Override
    public void execute(String id) throws EquipoAppException
    {
        repository.delete(id);
    }
}
