package es.upsa.dasi.trabajoI_JavierPozo.wscontratos.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

import java.util.Optional;

public interface GetContratoByIdUseCase
{
    Optional<Contrato> execute(String id) throws EquipoAppException;
}
