package es.upsa.dasi.trabajoI_JavierPozo.wscontratos.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wscontratos.application.GetContratoUseCase;
import es.upsa.dasi.trabajoI_JavierPozo.wscontratos.domain.repository.Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.List;

@ApplicationScoped
public class GetContratoUseCaseImpl implements GetContratoUseCase
{
    @Inject
    Repository repository;

    @Override
    public List<Contrato> execute() throws EquipoAppException
    {
        return repository.getContratos();
    }
}
