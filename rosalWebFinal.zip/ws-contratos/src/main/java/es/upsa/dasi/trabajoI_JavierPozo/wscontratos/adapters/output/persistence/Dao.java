package es.upsa.dasi.trabajoI_JavierPozo.wscontratos.adapters.output.persistence;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

import java.util.List;
import java.util.Optional;

public interface Dao
{
    List<Contrato> findAll() throws EquipoAppException;
    Optional<Contrato> findById(String id) throws EquipoAppException;
    List<Contrato> findByEquipoId(String id) throws EquipoAppException;
    List<Contrato> findByPersonaId(String id) throws EquipoAppException;
    Contrato insertContrato(Contrato contrato) throws EquipoAppException;
    Optional<Contrato> updateContrato(Contrato contrato) throws EquipoAppException;
    void deleteContrato(String id) throws EquipoAppException;
}
