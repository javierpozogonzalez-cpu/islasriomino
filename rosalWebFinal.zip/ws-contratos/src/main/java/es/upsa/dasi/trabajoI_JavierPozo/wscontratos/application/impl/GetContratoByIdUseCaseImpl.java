package es.upsa.dasi.trabajoI_JavierPozo.wscontratos.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wscontratos.application.GetContratoByIdUseCase;
import es.upsa.dasi.trabajoI_JavierPozo.wscontratos.domain.repository.Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.Optional;

@ApplicationScoped
public class GetContratoByIdUseCaseImpl implements GetContratoByIdUseCase
{
    @Inject
    Repository repository;

    @Override
    public Optional<Contrato> execute(String id) throws EquipoAppException
    {
        return repository.getContratoById(id);
    }
}
