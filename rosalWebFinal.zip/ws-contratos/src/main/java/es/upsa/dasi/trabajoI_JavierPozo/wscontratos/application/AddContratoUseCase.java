package es.upsa.dasi.trabajoI_JavierPozo.wscontratos.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

public interface AddContratoUseCase
{
    Contrato execute(Contrato contrato) throws EquipoAppException;
}
