package es.upsa.dasi.trabajoI_JavierPozo.wscontratos.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

public interface DeleteContratoUseCase
{
    void execute(String id) throws EquipoAppException;
}
