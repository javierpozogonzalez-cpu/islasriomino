package es.upsa.dasi.trabajoI_JavierPozo.wscontratos.domain.repository;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

import java.util.List;
import java.util.Optional;

public interface Repository
{
    List<Contrato> getContratos() throws EquipoAppException;
    Optional<Contrato> getContratoById(String id) throws EquipoAppException;
    List<Contrato> getContratoByEquipoId(String equipoId) throws EquipoAppException;
    List<Contrato> getContratoByPersonaId(String jugadorId) throws EquipoAppException;
    Contrato save(Contrato contrato) throws EquipoAppException;
    void delete(String id) throws EquipoAppException;
}
