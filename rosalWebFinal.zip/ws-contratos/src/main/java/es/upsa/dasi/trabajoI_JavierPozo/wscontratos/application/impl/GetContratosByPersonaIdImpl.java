package es.upsa.dasi.trabajoI_JavierPozo.wscontratos.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wscontratos.application.GetContratosByPersonaId;
import es.upsa.dasi.trabajoI_JavierPozo.wscontratos.domain.repository.Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.List;

@ApplicationScoped
public class GetContratosByPersonaIdImpl implements GetContratosByPersonaId
{
    @Inject
    Repository repository;

    @Override
    public List<Contrato> execute(String personaId) throws EquipoAppException
    {
        return repository.getContratoByPersonaId(personaId);
    }
}
