package es.upsa.dasi.trabajoI_JavierPozo.wscontratos.domain.repository.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.ContratoNotFoundException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wscontratos.adapters.output.persistence.Dao;
import es.upsa.dasi.trabajoI_JavierPozo.wscontratos.domain.repository.Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.List;
import java.util.Optional;

@ApplicationScoped
public class RepositoryImpl implements Repository
{
    @Inject
    Dao dao;

    @Override
    public List<Contrato> getContratos() throws EquipoAppException
    {
        return dao.findAll();
    }

    @Override
    public Optional<Contrato> getContratoById(String id) throws EquipoAppException
    {
        return dao.findById(id);
    }

    @Override
    public List<Contrato> getContratoByEquipoId(String equipoId) throws EquipoAppException
    {
        return dao.findByEquipoId(equipoId);
    }

    @Override
    public List<Contrato> getContratoByPersonaId(String personaId) throws EquipoAppException
    {
        return dao.findByPersonaId(personaId);
    }

    @Override
    public Contrato save(Contrato contrato) throws EquipoAppException
    {
        return (contrato.getId() == null) ? dao.insertContrato(contrato) : dao.updateContrato(contrato)
                                                                              .orElseThrow(() -> new ContratoNotFoundException());
    }

    @Override
    public void delete(String id) throws EquipoAppException
    {
        dao.deleteContrato(id);
    }
}
