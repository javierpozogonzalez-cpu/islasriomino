package es.upsa.dasi.web.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;

import java.util.Optional;

public interface FindEquipoByIdUsecase
{
    Optional<Equipo> execute(String id);
}
