package es.upsa.dasi.web.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.aggregators.EquipoWithContratos;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.ContratoConPersona;
import es.upsa.dasi.web.application.impl.FindContratosByEquipoIdUsecaseImpl;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface FindContratosByEquipoIdUsecase
{
    Optional<EquipoWithContratos> execute(String equipoId);
}
