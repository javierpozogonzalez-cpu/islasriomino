package es.upsa.dasi.web.adapters.input.rest.dtos;

import jakarta.mvc.binding.MvcBinding;
import jakarta.validation.constraints.*;
import jakarta.ws.rs.FormParam;
import lombok.Data;

import java.time.LocalDate;

@Data
public class ContratoForm
{
    @FormParam("nombre")
    @MvcBinding
    @NotNull
    @NotEmpty
    @Size(min = 2, max = 100)
    String nombre;

    @FormParam("nacionalidad")
    @MvcBinding
    @NotNull
    @NotEmpty
    @Size(min = 2, max = 50)
    String nacionalidad;

    @FormParam("fechaNacimiento")
    @MvcBinding
    String fechaNacimientoString;

    @FormParam("foto")
    @MvcBinding
    @Size(max = 500)
    String foto;

    @FormParam("tipo")
    @MvcBinding
    @NotNull
    @NotEmpty
    @Pattern(regexp = "JUGADOR|ENTRENADOR", message = "El tipo debe ser JUGADOR o ENTRENADOR")
    String tipo;

    @FormParam("posicion")
    @MvcBinding
    @Size(max = 100)
    String posicion;

    public LocalDate getFechaNacimientoAsLocalDate()
    {
        return LocalDate.parse(fechaNacimientoString);
    }
}
