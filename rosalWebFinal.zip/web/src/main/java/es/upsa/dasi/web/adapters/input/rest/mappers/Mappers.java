package es.upsa.dasi.web.adapters.input.rest.mappers;

import es.upsa.dasi.trabajoI_JavierPozo.domain.dtos.ContratoDto;
import es.upsa.dasi.trabajoI_JavierPozo.domain.dtos.EquipoDto;
import es.upsa.dasi.trabajoI_JavierPozo.domain.dtos.PersonaDto;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Tipo;
import es.upsa.dasi.web.adapters.input.rest.dtos.ContratoForm;
import es.upsa.dasi.web.adapters.input.rest.dtos.EquipoForm;

public class Mappers
{
    public static EquipoDto toEquipoDto(EquipoForm equipoForm)
    {
        return EquipoDto.builder()
                        .withNombre(equipoForm.getNombre())
                        .withFundacion(equipoForm.getFundacionAsLocalDate())
                        .withPresupuesto(equipoForm.getPresupuesto())
                        .withHistoria(equipoForm.getHistoria())
                        .withEscudo(equipoForm.getEscudo())
                        .build();
    }

    public static PersonaDto toPersonaDto(ContratoForm contratoForm)
    {
        return PersonaDto.builder()
                         .withNombre(contratoForm.getNombre())
                         .withNacionalidad(contratoForm.getNacionalidad())
                         .withFechaNacimiento(contratoForm.getFechaNacimientoAsLocalDate())
                         .withFoto(contratoForm.getFoto())
                         .build();
    }

    public static ContratoDto toContratoDto(ContratoForm contratoForm, String equipoId, String personaId)
    {
        return ContratoDto.builder()
                          .withIdPersona(personaId)
                          .withIdEquipo(equipoId)
                          .withTipo(Tipo.valueOf(contratoForm.getTipo()))
                          .withPosicion(contratoForm.getPosicion())
                          .build();
    }
}
