package es.upsa.dasi.web.domain.exceptions;

public class EquipoAppRunTimeException extends RuntimeException
{
    public EquipoAppRunTimeException() {
    }

    public EquipoAppRunTimeException(String message) {
        super(message);
    }

    public EquipoAppRunTimeException(String message, Throwable cause) {
        super(message, cause);
    }

    public EquipoAppRunTimeException(Throwable cause) {
        super(cause);
    }

    public EquipoAppRunTimeException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
