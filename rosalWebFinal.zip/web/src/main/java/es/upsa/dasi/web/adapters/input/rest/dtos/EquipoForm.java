package es.upsa.dasi.web.adapters.input.rest.dtos;

import jakarta.mvc.binding.MvcBinding;
import jakarta.validation.constraints.*;
import jakarta.ws.rs.FormParam;
import lombok.Data;

import java.time.LocalDate;

@Data
public class EquipoForm
{
    @FormParam("nombre")
    @MvcBinding
    @NotNull
    @NotEmpty
    @Size(min = 1, max = 100)
    String nombre;

    @FormParam("fundacion")
    @MvcBinding
    String fundacionString;

    @FormParam("presupuesto")
    @MvcBinding
    @DecimalMin(value = "0.0", inclusive = true)
    @DecimalMax(value = "1000000000.0", inclusive = true)
    @Digits(integer = 10, fraction = 2)
    double presupuesto;

    @FormParam("historia")
    @MvcBinding
    @NotNull
    @Size(min = 10, max = 1000)
    @NotBlank
    String historia;

    @FormParam("escudo")
    @MvcBinding
    @NotNull
    @Size(min = 20, max = 200)
    @NotBlank
    String escudo;

    public LocalDate getFundacionAsLocalDate()
    {
        return LocalDate.parse(fundacionString);
    }
}
