package es.upsa.dasi.web.adapters.input.rest;

import es.upsa.dasi.trabajoI_JavierPozo.domain.aggregators.EquipoWithContratos;
import es.upsa.dasi.trabajoI_JavierPozo.domain.dtos.EquipoDto;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.ContratoConPersona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.web.adapters.input.rest.dtos.Action;
import es.upsa.dasi.web.adapters.input.rest.dtos.EquipoForm;
import es.upsa.dasi.web.adapters.input.rest.mappers.Mappers;
import es.upsa.dasi.web.application.*;
import es.upsa.dasi.web.domain.exceptions.EquipoAppRunTimeException;
import es.upsa.dasi.web.domain.exceptions.EquipoNotFoundRuntimeException;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.mvc.*;
import jakarta.mvc.binding.BindingResult;
import jakarta.mvc.binding.ParamError;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.*;
import java.util.stream.Collectors;

@ApplicationScoped
@Path("/equipos")
public class EquiposResource
{
    @Inject
    FindEquiposUsecase findEquiposUsecase;

    @Inject
    FindEquipoByIdUsecase findEquipoByIdUsecase;

    @Inject
    UpdateEquipoByIdUsecase updateEquipoByIdUsecase;

    @Inject
    DeleteEquipoByIdUsecase deleteEquipoByIdUsecase;

    @Inject
    InsertEquipoUsecase insertEquipoUsecase;

    @Inject
    FindContratosByEquipoIdUsecase findContratosByEquipoIdUsecase;

    @Inject
    Models models;

    @Inject
    MvcContext mvc;

    @Inject
    BindingResult bindingResult;

    @GET
    @Controller
    @UriRef("findEquipos")
    @View("/jsps/equipos.jsp")
    public void findEquipos() {
        try
        {
            System.out.println(">> Ejecutando findEquipos()");
            List<Equipo> equipos = findEquiposUsecase.execute();
            System.out.println(">> Equipos obtenidos: " + equipos);
            models.put("equipos", equipos);

        } catch (Exception e)
        {
            e.printStackTrace();
            models.put("errorMessage", e.getMessage());
            throw new EquipoAppRunTimeException("Error al obtener los equipos", e);
        }
    }

    @GET
    @Path("/{id}")
    @Controller
    @UriRef("findEquipoById")
    public Response findEquipoById(@PathParam("id") String id)
    {
        Optional<Equipo> optEquipo = findEquipoByIdUsecase.execute(id);

        if (optEquipo.isEmpty()) return Response.ok("/jsps/equipoNotFound.jsp").build();

        models.put("action", Action.VIEW);
        models.put("equipo", optEquipo.get());

        Optional<EquipoWithContratos> contratosPorEquipo = findContratosByEquipoIdUsecase.execute(id);

        if (contratosPorEquipo.isPresent()) {
            EquipoWithContratos equipoWithContratos = contratosPorEquipo.get();

            // Crear el Map que espera el JSP
            Map<String, List<?>> contratosPorTipo = new HashMap<>();

            // Agregar entrenadores si existen
            if (equipoWithContratos.getEntrenadores() != null) {
                contratosPorTipo.put("ENTRENADOR", equipoWithContratos.getEntrenadores());
            } else {
                contratosPorTipo.put("ENTRENADOR", new ArrayList<>());
            }

            // Agregar jugadores si existen
            if (equipoWithContratos.getJugadores() != null) {
                contratosPorTipo.put("JUGADOR", equipoWithContratos.getJugadores());
            } else {
                contratosPorTipo.put("JUGADOR", new ArrayList<>());
            }

            models.put("contratosPorTipo", contratosPorTipo);
        } else {
            // Si no hay datos, crear Map vacío
            Map<String, List<?>> contratosPorTipo = new HashMap<>();
            contratosPorTipo.put("ENTRENADOR", new ArrayList<>());
            contratosPorTipo.put("JUGADOR", new ArrayList<>());
            models.put("contratosPorTipo", contratosPorTipo);
        }

        return Response.ok("/jsps/equipo.jsp").build();
    }

    @PUT
    @Path("/{id}")
    @UriRef("updateEquipoById")
    @Controller
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response updateEquipoById(@PathParam("id") String id, @Valid @BeanParam EquipoForm equipoForm)
    {
        EquipoDto equipoDto = Mappers.toEquipoDto(equipoForm);

        try
        {
            if (bindingResult.isFailed())
            {
                Map<String, List<String>> errores = new HashMap<>();

                Set<ParamError> allErrors = bindingResult.getAllErrors();
                for (ParamError paramError : allErrors)
                {
                    List<String> messages = errores.get(paramError.getParamName());
                    if (messages == null) messages = new ArrayList<>();
                    messages.add(paramError.getMessage());

                    errores.put(paramError.getParamName(), messages);
                }

                Map<String, List<String>> errs = bindingResult.getAllErrors()
                        .stream()
                        .collect(Collectors.groupingBy(ParamError::getParamName,
                                        Collectors.mapping(ParamError::getMessage, Collectors.toList())
                                )
                        );

                Equipo equipo = es.upsa.dasi.trabajoI_JavierPozo.domain.mappers.Mappers.toEquipo(equipoDto).withId(id);

                models.put("action", Action.UPDATE);
                models.put("equipo", equipo);
                models.put("errores", errs);

                return Response.ok("/jsps/equipo.jsp").build();
            }

            Optional<Equipo> optionalEquipo = updateEquipoByIdUsecase.execute(id, equipoDto);

            if (optionalEquipo.isEmpty()) {
                return Response.ok("/jsps/equipoNotFound.jsp").build();
            }

            return Response.seeOther(mvc.uri("findEquipos", Map.of("locale", mvc.getLocale().toString()))).build();

        } catch (InternalServerErrorException exception)
        {
            models.put("errorMessage", exception.getMessage());

            return Response.ok("/jsps/error.jsp").build();
        }
    }

    @POST
    @UriRef("insertEquipo")
    @Controller
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response insertEquipo(@Valid @BeanParam EquipoForm equipoForm)
    {
        EquipoDto equipoDto = Mappers.toEquipoDto(equipoForm);

        try
        {
            if (bindingResult.isFailed())
            {
                Map<String, List<String>> errores = new HashMap<>();

                Set<ParamError> allErrors = bindingResult.getAllErrors();
                for (ParamError paramError : allErrors)
                {
                    List<String> messages = errores.get(paramError.getParamName());
                    if (messages == null) messages = new ArrayList<>();
                    messages.add(paramError.getMessage());

                    errores.put(paramError.getParamName(), messages);
                }

                Map<String, List<String>> errs = bindingResult.getAllErrors()
                        .stream()
                        .collect(Collectors.groupingBy(ParamError::getParamName,
                                        Collectors.mapping(ParamError::getMessage, Collectors.toList())
                                )
                        );

                Equipo equipo = es.upsa.dasi.trabajoI_JavierPozo.domain.mappers.Mappers.toEquipo(equipoDto);

                models.put("action", Action.INSERT);
                models.put("equipo", equipo);
                models.put("errores", errs);

                return Response.ok("/jsps/equipo.jsp").build();
            }

            Equipo equipo = insertEquipoUsecase.execute(equipoDto);

            return Response.seeOther(mvc.uri("findEquipos", Map.of("locale", mvc.getLocale()))).build();

        } catch (InternalServerErrorException exception)
        {
            models.put("errorMessage", exception.getMessage());
            return Response.ok("/jsps/error.jsp").build();
        }
    }

    @DELETE
    @Path("/{id}")
    @UriRef("deleteEquipoById")
    @Controller
    public Response deleteEquipoById(@PathParam("id") String id)
    {
        try
        {
            deleteEquipoByIdUsecase.execute(id);

            return Response.seeOther(mvc.uri("findEquipos", Map.of("locale", mvc.getLocale().toString()))).build();

        } catch (EquipoNotFoundRuntimeException exception)
        {
            return Response.ok("/jsps/equipoNotFound.jsp").build();
        }
        catch (InternalServerErrorException exception)
        {
            models.put("errorMessage", exception.getMessage());

            return Response.ok("/jsps/error.jsp").build();
        }
    }
}
