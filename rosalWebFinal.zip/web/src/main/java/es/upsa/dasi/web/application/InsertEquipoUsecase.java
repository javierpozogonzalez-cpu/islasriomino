package es.upsa.dasi.web.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.dtos.EquipoDto;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;

public interface InsertEquipoUsecase
{
    Equipo execute(EquipoDto equipoDto);
}
