package es.upsa.dasi.web.adapters.input.rest;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.ContratoConPersona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.web.adapters.input.rest.dtos.Action;
import es.upsa.dasi.web.application.*;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.UriRef;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.core.Response;

import java.util.Optional;

@ApplicationScoped
@Path("/forms")
public class FormulResource
{
    @Inject
    FindEquipoByIdUsecase findEquipoByIdUsecase;

    @Inject
    FindContratoByIdUsecase findContratoByIdUsecase;

    @Inject
    FindPersonaByIdUseCase findPersonaByIdUseCase;

    @Inject
    Models models;

    @GET
    @Path("/update/equipo/{id}")
    @Controller
    @UriRef("formUpdateEquipoById")
    public Response formUpdateEquipoById(@PathParam("id") String id)
    {
        Optional<Equipo> optionalEquipo = findEquipoByIdUsecase.execute(id);

        if (optionalEquipo.isEmpty()) return Response.ok("/jsps/equipoNotFound.jsp").build();

        models.put("action", Action.UPDATE);
        models.put("equipo", optionalEquipo.get());

        return Response.ok("/jsps/equipo.jsp").build();
    }

    @GET
    @Path("/delete/equipo/{id}")
    @Controller
    @UriRef("formDeleteEquipoById")
    public Response formDeleteEquipoById(@PathParam("id") String id)
    {
        Optional<Equipo> optionalEquipo = findEquipoByIdUsecase.execute(id);

        if (optionalEquipo.isEmpty()) return Response.ok("/jsps/equipoNotFound.jsp").build();

        models.put("action", Action.DELETE);
        models.put("equipo", optionalEquipo.get());

        return Response.ok("/jsps/equipo.jsp").build();
    }

    @GET
    @Path("/insert/equipo")
    @Controller
    @UriRef("formInsertEquipo")
    public Response formInsertEquipo()
    {
        models.put("action", Action.INSERT);

        return Response.ok("/jsps/equipo.jsp").build();
    }

    @GET
    @Path("/insert/contrato/{equipoId}")
    @Controller
    @UriRef("formInsertContrato")
    public Response formInsertContrato(@PathParam("equipoId") String equipoId)
    {
        Optional<Equipo> optionalEquipo = findEquipoByIdUsecase.execute(equipoId);

        if (optionalEquipo.isEmpty()) return Response.ok("/jsps/equipoNotFound.jsp").build();

        models.put("action", Action.INSERT);
        models.put("equipo", optionalEquipo.get());

        return Response.ok("/jsps/contrato.jsp").build();
    }

    @GET
    @Path("/delete/contrato/{id}")
    @Controller
    @UriRef("formDeleteContrato")
    public Response formDeleteContrato(@PathParam("id") String id)
    {
        try {
            Optional<Contrato> optionalContrato = findContratoByIdUsecase.execute(id);
            if (optionalContrato.isEmpty()) {
                models.put("errorMessage", "Contrato no encontrado");
                return Response.ok("/jsps/error.jsp").build();
            }

            Contrato contrato = optionalContrato.get();

            Optional<Persona> optionalPersona = findPersonaByIdUseCase.execute(contrato.getIdPersona());
            if (optionalPersona.isEmpty()) {
                models.put("errorMessage", "Persona no encontrada");
                return Response.ok("/jsps/error.jsp").build();
            }

            Persona persona = optionalPersona.get();

            Optional<Equipo> optionalEquipo = findEquipoByIdUsecase.execute(contrato.getIdEquipo());
            if (optionalEquipo.isEmpty()) {
                models.put("errorMessage", "Equipo no encontrado");
                return Response.ok("/jsps/error.jsp").build();
            }

            Equipo equipo = optionalEquipo.get();

            models.put("action", Action.DELETE);
            models.put("contratoObj", contrato);
            models.put("personaObj", persona);
            models.put("equipo", equipo);

            return Response.ok("/jsps/contrato.jsp").build();

        } catch (Exception e) {
            models.put("errorMessage", "Error: " + e.getMessage());
            return Response.ok("/jsps/error.jsp").build();
        }
    }
}
