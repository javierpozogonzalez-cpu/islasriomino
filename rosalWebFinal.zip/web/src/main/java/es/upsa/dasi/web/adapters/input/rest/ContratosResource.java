package es.upsa.dasi.web.adapters.input.rest;

import es.upsa.dasi.trabajoI_JavierPozo.domain.dtos.ContratoDto;
import es.upsa.dasi.trabajoI_JavierPozo.domain.dtos.PersonaDto;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.web.adapters.input.rest.dtos.ContratoForm;
import es.upsa.dasi.web.adapters.input.rest.mappers.Mappers;
import es.upsa.dasi.web.application.*;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.mvc.Controller;
import jakarta.mvc.Models;
import jakarta.mvc.MvcContext;
import jakarta.mvc.UriRef;
import jakarta.mvc.binding.BindingResult;
import jakarta.mvc.binding.ParamError;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.*;
import java.util.stream.Collectors;

@ApplicationScoped
@Path("/contratos")
public class ContratosResource
{
    @Inject
    InsertContratoUseCase insertContratoUseCase;

    @Inject
    InsertPersonaUseCase insertPersonaUseCase;

    @Inject
    DeleteContratoByIdUsecase deleteContratoByIdUsecase;

    @Inject
    FindEquipoByIdUsecase findEquipoByIdUsecase;

    @Inject
    FindContratoByIdUsecase findContratoByIdUsecase;

    @Inject
    Models models;

    @Inject
    MvcContext mvc;

    @Inject
    BindingResult bindingResult;

    @POST
    @Path("/equipo/{equipoId}")
    @UriRef("insertContrato")
    @Controller
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response insertContrato(@PathParam("equipoId") String equipoId, @Valid @BeanParam ContratoForm contratoForm) {
        try {
            if (bindingResult.isFailed()) {
                Map<String, List<String>> errores = new HashMap<>();
                Set<ParamError> allErrors = bindingResult.getAllErrors();
                for (ParamError paramError : allErrors) {
                    List<String> messages = errores.get(paramError.getParamName());
                    if (messages == null) messages = new ArrayList<>();
                    messages.add(paramError.getMessage());
                    errores.put(paramError.getParamName(), messages);
                }

                Map<String, List<String>> errs = bindingResult.getAllErrors()
                        .stream()
                        .collect(Collectors.groupingBy(ParamError::getParamName,
                                Collectors.mapping(ParamError::getMessage, Collectors.toList())
                        ));

                models.put("contratoForm", contratoForm);
                models.put("errores", errs);

                Optional<Equipo> optionalEquipo = findEquipoByIdUsecase.execute(equipoId);
                if (optionalEquipo.isPresent()) {
                    models.put("equipo", optionalEquipo.get());
                }
                return Response.ok("/jsps/contratoForm.jsp").build();
            }

            PersonaDto personaDto = Mappers.toPersonaDto(contratoForm);
            Persona persona = es.upsa.dasi.trabajoI_JavierPozo.domain.mappers.Mappers.toPersona(personaDto);
            Persona personaCreada = insertPersonaUseCase.execute(persona);

            ContratoDto contratoDto = Mappers.toContratoDto(contratoForm, equipoId, personaCreada.getId());
            Contrato contrato = es.upsa.dasi.trabajoI_JavierPozo.domain.mappers.Mappers.toContrato(contratoDto);
            insertContratoUseCase.execute(contrato);

            return Response.seeOther(mvc.uri("findEquipoById", Map.of("id", equipoId, "locale", mvc.getLocale().toString()))).build();

        } catch (InternalServerErrorException exception) {
            models.put("errorMessage", exception.getMessage());
            return Response.ok("/jsps/error.jsp").build();
        } catch (Exception e) {
            models.put("errorMessage", "Error al crear el contrato: " + e.getMessage());
            models.put("contratoForm", contratoForm);
            Optional<Equipo> optionalEquipo = findEquipoByIdUsecase.execute(equipoId);
            if (optionalEquipo.isPresent()) {
                models.put("equipo", optionalEquipo.get());
            }
            return Response.ok("/jsps/contratoForm.jsp").build();
        }
    }


    @DELETE
    @Path("/{id}")
    @UriRef("deleteContratoById")
    @Controller
    public Response deleteContratoById(@PathParam("id") String id) {
        System.out.println("=== DEBUGGING DELETE CONTRATO RESOURCE ===");
        System.out.println("ContratosResource.deleteContratoById() - ID: " + id);

        try {
            System.out.println("1. Iniciando eliminación...");
            Optional<Contrato> optionalContrato = findContratoByIdUsecase.execute(id);

            if (optionalContrato.isEmpty()) {
                System.err.println("ERROR: Contrato no encontrado en ContratosResource");
                models.put("errorMessage", "Contrato no encontrado con ID: " + id);
                return Response.ok("/jsps/error.jsp").build();
            }

            Contrato contrato = optionalContrato.get();
            String equipoId = contrato.getIdEquipo();
            System.out.println("2. Contrato encontrado, equipoId: " + equipoId);

            System.out.println("3. Eliminando contrato...");
            deleteContratoByIdUsecase.execute(id);
            System.out.println("4. Contrato eliminado exitosamente");

            System.out.println("5. Redirigiendo a equipo: " + equipoId);
            return Response.seeOther(mvc.uri("findEquipoById",
                    Map.of("id", equipoId, "locale", mvc.getLocale().toString()))).build();

        } catch (Exception e) {
            System.err.println("=== ERROR EN CONTRATOS RESOURCE ===");
            System.err.println("Error en ContratosResource.deleteContratoById: " + e.getMessage());
            System.err.println("Tipo de excepción: " + e.getClass().getName());
            e.printStackTrace();

            models.put("errorMessage", "Error al eliminar el contrato: " + e.getMessage());
            return Response.ok("/jsps/error.jsp").build();
        }
    }
}
