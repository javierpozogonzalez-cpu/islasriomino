package es.upsa.dasi.web.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.web.application.InsertContratoUseCase;
import es.upsa.dasi.web.infrastructure.rest.GatewayRestClient;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.eclipse.microprofile.rest.client.inject.RestClient;

@ApplicationScoped
public class InsertContratoUseCaseImpl implements InsertContratoUseCase
{
    @Inject
    @RestClient
    GatewayRestClient restClient;

    @Override
    public Contrato execute(Contrato contrato)
    {
        return restClient.insertContrato(contrato);
    }
}
