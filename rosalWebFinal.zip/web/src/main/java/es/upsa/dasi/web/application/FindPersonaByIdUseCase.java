package es.upsa.dasi.web.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;

import java.util.Optional;

public interface FindPersonaByIdUseCase
{
    Optional<Persona> execute(String id);
}
