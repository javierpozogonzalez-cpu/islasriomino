package es.upsa.dasi.web.application;

public interface DeleteContratoByIdUsecase
{
    String execute(String contratoId);
}
