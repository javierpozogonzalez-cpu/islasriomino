package es.upsa.dasi.web.domain.exceptions;

import jakarta.ws.rs.NotFoundException;

public class EquipoNotFoundRuntimeException extends EquipoAppRunTimeException
{
    public EquipoNotFoundRuntimeException()
    {
        super("Equipo no encontrado");
    }
}
