package es.upsa.dasi.web.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.aggregators.EquipoWithContratos;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.ContratoConPersona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.mappers.Mappers;
import es.upsa.dasi.web.application.FindContratosByEquipoIdUsecase;
import es.upsa.dasi.web.infrastructure.rest.GatewayRestClient;
import jakarta.enterprise.context.ApplicationScoped;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import jakarta.inject.Inject;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@ApplicationScoped
public class FindContratosByEquipoIdUsecaseImpl implements FindContratosByEquipoIdUsecase
{
    @Inject
    @RestClient
    GatewayRestClient gatewayRestClient;

    public Optional<EquipoWithContratos> execute(String equipoId)
    {
        try
        {
            return gatewayRestClient.findContratosByEquipoId(equipoId);

        } catch (Exception e)
          {
              System.err.println("Error obteniendo contratos para equipo " + equipoId + ": " + e.getMessage());
              return Optional.empty();
          }
    }
}
