package es.upsa.dasi.web.infrastructure.rest.providers;

import es.upsa.dasi.trabajoI_JavierPozo.domain.dtos.ErrorDto;
import es.upsa.dasi.web.domain.exceptions.EquipoAppRunTimeException;
import es.upsa.dasi.web.domain.exceptions.EquipoNotFoundRuntimeException;
import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.ext.ResponseExceptionMapper;

public class EquipoResponseExceptionMapper implements ResponseExceptionMapper<EquipoAppRunTimeException>
{
    @Override
    public EquipoAppRunTimeException toThrowable(Response response)
    {
        Response.Status status = response.getStatusInfo().toEnum();
        return switch (status)
        {
            case NOT_FOUND -> new EquipoNotFoundRuntimeException();

            default        -> {
                                  ErrorDto errorDto = response.readEntity(ErrorDto.class);
                                  yield new EquipoAppRunTimeException( errorDto.getMessage() );
                              }
        };
    }
}
