package es.upsa.dasi.web.application.impl;

import es.upsa.dasi.web.application.DeleteEquipoByIdUsecase;
import es.upsa.dasi.web.domain.exceptions.EquipoAppRunTimeException;
import es.upsa.dasi.web.infrastructure.rest.GatewayRestClient;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RestClient;

@ApplicationScoped
public class DeleteEquipoByIdUsecaseImpl implements DeleteEquipoByIdUsecase
{
    @Inject
    @RestClient
    GatewayRestClient gatewayRestClient;

    @Override
    public void execute(String id)
    {
        try
        {
            gatewayRestClient.deleteContratosByEquipoId(id);
            gatewayRestClient.deleteEquipoById(id);
        } catch (Exception e)
          {
              gatewayRestClient.deleteEquipoById(id);
          }
    }
}
