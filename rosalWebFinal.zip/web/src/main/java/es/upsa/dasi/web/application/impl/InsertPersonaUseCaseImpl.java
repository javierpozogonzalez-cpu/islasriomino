package es.upsa.dasi.web.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.web.application.InsertPersonaUseCase;
import es.upsa.dasi.web.infrastructure.rest.GatewayRestClient;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.eclipse.microprofile.rest.client.inject.RestClient;

@ApplicationScoped
public class InsertPersonaUseCaseImpl implements InsertPersonaUseCase
{
    @Inject
    @RestClient
    GatewayRestClient restClient;

    @Override
    public Persona execute(Persona persona)
    {
        return restClient.insertPersona(persona);
    }
}
