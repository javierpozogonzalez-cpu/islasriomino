package es.upsa.dasi.web.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;

public interface InsertPersonaUseCase
{
    Persona execute(Persona persona);
}
