package es.upsa.dasi.web.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.dtos.EquipoDto;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.web.application.UpdateEquipoByIdUsecase;
import es.upsa.dasi.web.domain.exceptions.EquipoNotFoundRuntimeException;
import es.upsa.dasi.web.infrastructure.rest.GatewayRestClient;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.util.Optional;

@ApplicationScoped
public class UpdateEquipoByIdUsecaseImpl implements UpdateEquipoByIdUsecase
{
    @Inject
    @RestClient
    GatewayRestClient restClient;

    @Override
    public Optional<Equipo> execute(String id, EquipoDto equipoDto)
    {
        try
        {
            Equipo equipo = restClient.updateEquipoById(id, equipoDto);
            return Optional.of(equipo);

        } catch (EquipoNotFoundRuntimeException exception)
          {
            return Optional.empty();
          }
    }
}
