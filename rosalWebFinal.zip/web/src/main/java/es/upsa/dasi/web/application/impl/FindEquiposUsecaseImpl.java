package es.upsa.dasi.web.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.web.application.FindEquiposUsecase;
import es.upsa.dasi.web.domain.exceptions.EquipoAppRunTimeException;
import es.upsa.dasi.web.infrastructure.rest.GatewayRestClient;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@ApplicationScoped
public class FindEquiposUsecaseImpl implements FindEquiposUsecase
{
    private static final Logger logger = Logger.getLogger(FindEquiposUsecaseImpl.class.getName());

    @Inject
    @RestClient
    GatewayRestClient restClient;

    @Override
    public List<Equipo> execute()
    {
        try {
            logger.info("Obteniendo lista de equipos...");
            List<Equipo> equipos = restClient.findEquipos();

            // Ordenar por ID para mantener consistencia
            equipos.sort((e1, e2) -> e1.getId().compareTo(e2.getId()));

            logger.info("Equipos obtenidos: " + equipos.size());
            return equipos;
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error al obtener equipos", e);
            throw new EquipoAppRunTimeException("Error al obtener los equipos: " + e.getMessage());
        }
    }
}
