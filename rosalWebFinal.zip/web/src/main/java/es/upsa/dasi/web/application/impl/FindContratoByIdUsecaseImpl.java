package es.upsa.dasi.web.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.ContratoConPersona;
import es.upsa.dasi.web.application.FindContratoByIdUsecase;
import es.upsa.dasi.web.domain.exceptions.EquipoAppRunTimeException;
import es.upsa.dasi.web.infrastructure.rest.GatewayRestClient;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.util.Optional;

@ApplicationScoped
public class FindContratoByIdUsecaseImpl implements FindContratoByIdUsecase
{
    @Inject
    @RestClient
    GatewayRestClient restClient;

    @Override
    public Optional<Contrato> execute(String contratoId)
    {
        try {
            Contrato contrato = restClient.findContratoByIdOnlyContrato(contratoId);

            return Optional.ofNullable(contrato);

        } catch (Exception e)
          {
              throw new EquipoAppRunTimeException("Error al buscar el contrato: " + e.getMessage());
          }
    }
}
