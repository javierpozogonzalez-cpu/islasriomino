package es.upsa.dasi.web.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.web.application.FindPersonaByIdUseCase;
import es.upsa.dasi.web.infrastructure.rest.GatewayRestClient;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.util.Optional;

@ApplicationScoped
public class FindPersonaByIdUseCaseImpl implements FindPersonaByIdUseCase
{
    @Inject
    @RestClient
    GatewayRestClient restClient;

    @Override
    public Optional<Persona> execute(String id)
    {
        return restClient.findPersonaById(id);
    }
}
