package es.upsa.dasi.web.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.dtos.EquipoDto;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;

import java.util.Optional;

public interface UpdateEquipoByIdUsecase
{
    Optional<Equipo> execute(String id, EquipoDto equipoDto);
}
