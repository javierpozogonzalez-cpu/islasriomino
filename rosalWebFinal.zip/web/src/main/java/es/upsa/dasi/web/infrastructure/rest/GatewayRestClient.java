package es.upsa.dasi.web.infrastructure.rest;

import es.upsa.dasi.trabajoI_JavierPozo.domain.aggregators.EquipoWithContratos;
import es.upsa.dasi.trabajoI_JavierPozo.domain.dtos.EquipoDto;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.ContratoConPersona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.web.infrastructure.rest.providers.EquipoResponseExceptionMapper;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RegisterRestClient(baseUri = "http://localhost:8084")
@RegisterProvider(EquipoResponseExceptionMapper.class)
public interface GatewayRestClient
{
    @GET
    @Path("/equipos")
    @Produces(MediaType.APPLICATION_JSON)
    List<Equipo> findEquipos();

    @GET
    @Path("/equipos/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    Equipo findEquipoById(@PathParam("id") String id);

    @POST
    @Path("/equipos")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    Equipo insertEquipo(EquipoDto equipoDto);

    @PUT
    @Path("/equipos/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    Equipo updateEquipoById(@PathParam("id") String id, EquipoDto equipoDto);

    @DELETE
    @Path("/equipos/{id}")
    Response deleteEquipoById(@PathParam("id") String id);

    @DELETE
    @Path("/equipos/{id}/contratos")
    Response deleteContratosByEquipoId(@PathParam("id") String id);

    // CONTRATOS
    @GET
    @Path("/contratos/equipos/{equipoId}")
    @Produces(MediaType.APPLICATION_JSON)
    Optional<EquipoWithContratos> findContratosByEquipoId(@PathParam("equipoId") String equipoId);

    // PERSONAS
    @GET
    @Path("/personas/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    Optional<Persona> findPersonaById(@PathParam("id") String id);

    @POST
    @Path("/personas")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    Persona insertPersona(Persona persona);

    @GET
    @Path("/contratos/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    ContratoConPersona findContratoById(@PathParam("id") String id);

    @GET
    @Path("/contratos/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    Contrato findContratoByIdOnlyContrato(@PathParam("id") String id);

    @POST
    @Path("/contratos")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    Contrato insertContrato(Contrato contrato);

    @DELETE
    @Path("/contratos/{id}")
    Response deleteContratoById(@PathParam("id") String id);
}
