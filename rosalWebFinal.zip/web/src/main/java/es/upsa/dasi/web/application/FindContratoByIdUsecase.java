package es.upsa.dasi.web.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.ContratoConPersona;

import java.util.Optional;

public interface FindContratoByIdUsecase
{
    Optional<Contrato> execute(String contratoId);
}
