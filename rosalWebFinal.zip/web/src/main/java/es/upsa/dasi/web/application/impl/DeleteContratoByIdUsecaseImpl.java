package es.upsa.dasi.web.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.ContratoConPersona;
import es.upsa.dasi.web.application.DeleteContratoByIdUsecase;
import es.upsa.dasi.web.domain.exceptions.EquipoAppRunTimeException;
import es.upsa.dasi.web.infrastructure.rest.GatewayRestClient;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.eclipse.microprofile.rest.client.inject.RestClient;

@ApplicationScoped
public class DeleteContratoByIdUsecaseImpl implements DeleteContratoByIdUsecase
{
    @Inject
    @RestClient
    GatewayRestClient restClient;

    @Override
    public String execute(String contratoId)
    {
        ContratoConPersona contrato = restClient.findContratoById(contratoId);

        if (contrato == null)
        {
            throw new EquipoAppRunTimeException("No se encontró el contrato con ID: " + contratoId);
        }

        String equipoId = contrato.getContrato().getIdEquipo();

        restClient.deleteContratoById(contratoId);

        return equipoId;
    }
}
