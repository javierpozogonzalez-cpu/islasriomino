package es.upsa.dasi.web.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;

public interface InsertContratoUseCase
{
    Contrato execute(Contrato contrato);
}
