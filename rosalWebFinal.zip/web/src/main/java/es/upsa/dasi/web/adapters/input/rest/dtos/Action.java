package es.upsa.dasi.web.adapters.input.rest.dtos;

public enum Action
{
    VIEW, UPDATE, INSERT, DELETE;
}
