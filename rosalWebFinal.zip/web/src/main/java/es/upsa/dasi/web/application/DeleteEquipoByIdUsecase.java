package es.upsa.dasi.web.application;

public interface DeleteEquipoByIdUsecase
{
    void execute(String id);
}
