package es.upsa.dasi.trabajoI_JavierPozo.wsequipos.domain.repository.Impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoNotFoundException;
import es.upsa.dasi.trabajoI_JavierPozo.wsequipos.adapters.output.persistence.Dao;
import es.upsa.dasi.trabajoI_JavierPozo.wsequipos.domain.repository.Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.List;
import java.util.Optional;

@ApplicationScoped
public class RepositoryImpl implements Repository
{
    @Inject
    Dao dao;

    @Override
    public List<Equipo> getEquipos() throws EquipoAppException
    {
        return dao.findAll();
    }

    @Override
    public Optional<Equipo> getEquipoById(String id) throws EquipoAppException
    {
        return dao.findEquipoById(id);
    }

    @Override
    public Equipo saveEquipo(Equipo equipo) throws EquipoAppException
    {
        return (equipo.getId() == null)? dao.insertEquipo(equipo) : dao.updateEquipo(equipo)
                                                                       .orElseThrow(() -> new EquipoNotFoundException());
    }

    @Override
    public void deleteEquipoById(String id) throws EquipoAppException
    {
        dao.deleteEquipoById(id);
    }

    @Override
    public void deleteContratosByEquipoId(String equipoId) throws EquipoAppException
    {
        dao.deleteContratosByEquipoId(equipoId);
    }
}
