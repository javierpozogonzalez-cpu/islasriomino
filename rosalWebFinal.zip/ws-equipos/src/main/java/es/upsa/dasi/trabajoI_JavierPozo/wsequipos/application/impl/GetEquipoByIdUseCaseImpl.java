package es.upsa.dasi.trabajoI_JavierPozo.wsequipos.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wsequipos.application.GetEquipoByIdUseCase;
import es.upsa.dasi.trabajoI_JavierPozo.wsequipos.domain.repository.Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.Optional;

@ApplicationScoped
public class GetEquipoByIdUseCaseImpl implements GetEquipoByIdUseCase
{
    @Inject
    Repository repository;

    @Override
    public Optional<Equipo> execute(String id) throws EquipoAppException
    {
        return repository.getEquipoById(id);
    }
}
