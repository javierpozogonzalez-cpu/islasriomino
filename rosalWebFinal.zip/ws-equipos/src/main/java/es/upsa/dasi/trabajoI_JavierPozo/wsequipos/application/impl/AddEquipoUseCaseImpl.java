package es.upsa.dasi.trabajoI_JavierPozo.wsequipos.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wsequipos.application.AddEquipoUseCase;
import es.upsa.dasi.trabajoI_JavierPozo.wsequipos.domain.repository.Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class AddEquipoUseCaseImpl implements AddEquipoUseCase
{
    @Inject
    Repository repository;

    @Override
    public Equipo execute(Equipo equipo) throws EquipoAppException
    {
        return repository.saveEquipo(equipo.withId(null));
    }
}
