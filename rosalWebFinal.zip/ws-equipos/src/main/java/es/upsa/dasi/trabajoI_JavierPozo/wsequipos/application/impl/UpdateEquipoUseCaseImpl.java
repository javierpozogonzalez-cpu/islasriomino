package es.upsa.dasi.trabajoI_JavierPozo.wsequipos.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wsequipos.application.UpdateEquipoUseCase;
import es.upsa.dasi.trabajoI_JavierPozo.wsequipos.domain.repository.Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class UpdateEquipoUseCaseImpl implements UpdateEquipoUseCase
{
    @Inject
    Repository repository;

    @Override
    public Equipo execute(Equipo equipo) throws EquipoAppException
    {
        return repository.saveEquipo(equipo);
    }
}
