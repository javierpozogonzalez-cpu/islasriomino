package es.upsa.dasi.trabajoI_JavierPozo.wsequipos.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wsequipos.application.GetEquiposUseCase;
import es.upsa.dasi.trabajoI_JavierPozo.wsequipos.domain.repository.Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.List;

@ApplicationScoped
public class GetEquiposUseCaseImpl implements GetEquiposUseCase
{
    @Inject
    Repository repository;

    @Override
    public List<Equipo> execute() throws EquipoAppException
    {
        return repository.getEquipos();
    }
}
