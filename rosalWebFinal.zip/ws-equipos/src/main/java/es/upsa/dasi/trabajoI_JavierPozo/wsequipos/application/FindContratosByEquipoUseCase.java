package es.upsa.dasi.trabajoI_JavierPozo.wsequipos.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

import java.util.List;

public interface FindContratosByEquipoUseCase {
    List<Contrato> execute(String equipoId) throws EquipoAppException;
}
