package es.upsa.dasi.trabajoI_JavierPozo.wsequipos.domain.exceptions;

import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

public class EquipoHasContratosSQLException extends EquipoAppException
{
    public EquipoHasContratosSQLException()
    {
        super("El equipo tiene contratos asociados y no puede ser eliminado");
    }
}
