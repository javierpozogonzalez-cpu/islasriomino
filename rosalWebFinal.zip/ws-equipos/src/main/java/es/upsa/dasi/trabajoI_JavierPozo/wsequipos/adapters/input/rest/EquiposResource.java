package es.upsa.dasi.trabajoI_JavierPozo.wsequipos.adapters.input.rest;

import es.upsa.dasi.trabajoI_JavierPozo.domain.dtos.EquipoDto;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoNotFoundException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.mappers.Mappers;
import es.upsa.dasi.trabajoI_JavierPozo.wsequipos.application.*;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;

@ApplicationScoped
@Path("/equipos")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class EquiposResource
{
    @Inject
    GetEquiposUseCase getEquiposUseCase;

    @Inject
    GetEquipoByIdUseCase getEquipoByIdUseCase;

    @Inject
    AddEquipoUseCase addEquipoUseCase;

    @Inject
    UpdateEquipoUseCase updatePeliculaUseCase;

    @Inject
    DeleteEquipoUseCase deleteEquipoUseCase;

    @Inject
    FindContratosByEquipoUseCase findContratosByEquipoUseCase;

    @GET
    public Response getEquipos() throws EquipoAppException
    {
        List<Equipo> equipos = getEquiposUseCase.execute();

        return Response.ok()
                       .entity(new GenericEntity<List<Equipo>>(equipos) {})
                       .build();
    }

    @GET
    @Path("/{id}")
    public Response getEquipoById(@PathParam("id") String id) throws EquipoAppException
    {
        Optional<Equipo> optEquipo = getEquipoByIdUseCase.execute(id);

        return optEquipo.map(equipo -> Response.ok().entity(equipo).build())
                        .orElseThrow(() -> new EquipoNotFoundException());
    }

    @POST
    public Response addEquipo(EquipoDto equipoDto, @Context UriInfo uriInfo) throws EquipoAppException
    {
        Equipo equipo = Mappers.toEquipo(equipoDto);
        Equipo insertedEquipo = addEquipoUseCase.execute(equipo);

        return Response.created(createEquipoURI(uriInfo, insertedEquipo))
                       .entity(insertedEquipo)
                       .build();
    }

    @PUT
    @Path("{id}")
    public Response updateEquipo(@PathParam("id") String id, EquipoDto equipoDto) throws EquipoAppException
    {
        Equipo equipo = Mappers.toEquipo(equipoDto)
                               .withId(id);

        Equipo updatedEquipo = updatePeliculaUseCase.execute(equipo);

        return Response.ok()
                       .entity(updatedEquipo)
                       .build();
    }

    @GET
    @Path("/{id}/contratos")
    public List<Contrato> findContratosByEquipo(@PathParam("id") String id) throws EquipoAppException {
        return findContratosByEquipoUseCase.execute(id);
    }

    @DELETE
    @Path("{id}")
    public Response deleteEquipo(@PathParam("id") String id) throws EquipoAppException
    {
        deleteEquipoUseCase.execute(id);

        return Response.noContent()
                       .build();
    }

    private URI createEquipoURI(UriInfo uriInfo, Equipo equipo)
    {
        return uriInfo.getBaseUriBuilder()
                      .path("/equipos/{id}")
                      .resolveTemplate("id", equipo.getId())
                      .build();
    }
}
