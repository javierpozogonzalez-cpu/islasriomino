package es.upsa.dasi.trabajoI_JavierPozo.wsequipos.adapters.input.rest.providers;

import es.upsa.dasi.trabajoI_JavierPozo.domain.dtos.ErrorDto;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoNotFoundException;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;

@Produces(MediaType.APPLICATION_JSON)
@Provider
public class EquipoExceptionMapper implements ExceptionMapper<EquipoAppException>
{

    @Override
    public Response toResponse(EquipoAppException exception)
    {
        ErrorDto errorDto = ErrorDto.builder()
                .withMessage(exception.getMessage())
                .build();

        if (exception instanceof EquipoNotFoundException)
        {
            return Response.status(Response.Status.NOT_FOUND)
                           .entity(errorDto)
                           .build();
        }

        return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                       .entity(errorDto)
                       .build();
    }
}
