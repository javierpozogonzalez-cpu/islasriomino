package es.upsa.dasi.trabajoI_JavierPozo.wsequipos.domain.exceptions;

import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

public class FieldBetweenSQLException extends EquipoAppException
{
    public FieldBetweenSQLException(String fieldName, String minValue, String maxValue)
    {
        super(String.format("El campo %s debe estar comprendido entre %s y %s", fieldName, minValue, maxValue));
    }
}
