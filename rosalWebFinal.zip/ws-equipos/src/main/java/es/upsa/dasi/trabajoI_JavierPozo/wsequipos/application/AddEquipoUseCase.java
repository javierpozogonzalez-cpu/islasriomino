package es.upsa.dasi.trabajoI_JavierPozo.wsequipos.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

public interface AddEquipoUseCase
{
    Equipo execute(Equipo equipo) throws EquipoAppException;
}
