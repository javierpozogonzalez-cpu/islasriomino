package es.upsa.dasi.trabajoI_JavierPozo.wsequipos.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoNotFoundException;

public interface DeleteEquipoUseCase
{
    void execute(String id) throws EquipoAppException;
}
