package es.upsa.dasi.trabajoI_JavierPozo.wsequipos.infrastructure.persistence;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Tipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoNotFoundException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.SQLEquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wsequipos.adapters.output.persistence.Dao;
import es.upsa.dasi.trabajoI_JavierPozo.wsequipos.domain.exceptions.EquipoHasContratosSQLException;
import es.upsa.dasi.trabajoI_JavierPozo.wsequipos.domain.exceptions.FieldBetweenSQLException;
import es.upsa.dasi.trabajoI_JavierPozo.wsequipos.domain.exceptions.FieldRequiredSQLException;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@ApplicationScoped
public class DaoImpl implements Dao
{
    @Inject
    DataSource dataSource;

    @Override
    public List<Equipo> findAll() throws EquipoAppException
    {
        final String SQL = """
                           SELECT e.id, e.nombre, e.fundacion, e.presupuesto, e.historia, e.escudo
                            FROM equipos e
                           """;
        List<Equipo> equipos = new ArrayList<>();

        try (
                Connection connection = dataSource.getConnection();
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(SQL)
            )
        {
            while (resultSet.next())
            {
                equipos.add(toEquipo(resultSet));
            }

            return equipos;

        } catch (SQLException sqlException)
          {
              throw manageException(sqlException);
          }
    }

    @Override
    public Optional<Equipo> findEquipoById(String id) throws EquipoAppException
    {
        final String SQL = """
                           SELECT e.id, e.nombre, e.fundacion, e.presupuesto, e.historia, e.escudo
                             FROM equipos e
                            WHERE e.id = ? 
                           """;

        try(
                Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SQL)
           )
        {
            preparedStatement.setString(1, id);

            try (ResultSet resultSet = preparedStatement.executeQuery())
            {
                return (!resultSet.next())? Optional.empty() : Optional.of(toEquipo(resultSet));
            }

        } catch (SQLException sqlException)
          {
              throw manageException(sqlException);
          }
    }

    @Override
    public Equipo insertEquipo(Equipo equipo) throws EquipoAppException
    {
        final String SQL = """
                           INSERT INTO equipos(id,                     nombre, fundacion, presupuesto, historia, escudo)
                                        VALUES(nextval('seq_equipos'), ?,      ?,         ?,           ?,        ?     ) 
                           """;
        final String[] fields = {"id"};

        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SQL, fields)
            )
        {
            preparedStatement.setString(1, equipo.getNombre());
            preparedStatement.setDate(2, Date.valueOf(equipo.getFundacion()));
            preparedStatement.setDouble(3, equipo.getPresupuesto());
            preparedStatement.setString(4, equipo.getHistoria());
            preparedStatement.setString(5, equipo.getEscudo());

            preparedStatement.executeUpdate();

            try (ResultSet resultSet = preparedStatement.getGeneratedKeys())
            {
                resultSet.next();
                String id = resultSet.getString(1);

                return equipo.withId(id);
            }

        } catch (SQLException sqlException)
          {
              throw manageException(sqlException);
          }
    }

    @Override
    public Optional<Equipo> updateEquipo(Equipo equipo) throws EquipoAppException
    {
        final String SQL = """
                          UPDATE equipos
                             SET nombre = ?,
                                 fundacion = ?,
                                 presupuesto = ?,
                                 historia = ?,
                                 escudo = ?
                           WHERE id = ?        
                          """;

        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SQL)
            )
        {
            preparedStatement.setString(1, equipo.getNombre());
            preparedStatement.setDate(2, Date.valueOf(equipo.getFundacion()));
            preparedStatement.setDouble(3, equipo.getPresupuesto());
            preparedStatement.setString(4, equipo.getHistoria());
            preparedStatement.setString(5, equipo.getEscudo());
            preparedStatement.setString(6, equipo.getId());

            int count = preparedStatement.executeUpdate();

            return (count == 0)? Optional.empty() : Optional.of(equipo);

        } catch (SQLException sqlException)
        {
            throw manageException(sqlException);
        }
    }

    @Override
    public void deleteEquipoById(String id) throws EquipoAppException
    {
        final String SQL = """
                          DELETE 
                            FROM equipos
                           WHERE id = ?
                          """;
        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SQL)
            )
        {
            preparedStatement.setString(1, id);
            int count = preparedStatement.executeUpdate();

            if (count == 0) throw new EquipoNotFoundException();

        } catch (SQLException sqlException)
        {
            throw manageException(sqlException);
        }
    }

    @Override
    public void deleteContratosByEquipoId(String equipoId) throws EquipoAppException
    {
        final String SQL = """
                      DELETE 
                        FROM contratos
                       WHERE id_equipo = ?
                      """;
        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SQL)
        )
        {
            preparedStatement.setString(1, equipoId);
            int count = preparedStatement.executeUpdate();

        } catch (SQLException sqlException)
        {
            throw manageException(sqlException);
        }
    }


    @Override
    public List<Contrato> findContratosByEquipo(String equipoId) throws EquipoAppException {
        final String SQL = """
        SELECT c.id, c.id_persona, c.id_equipo, c.tipo, c.posicion,
               p.nombre, p.nacionalidad, p.fecha_nacimiento, p.foto
        FROM contratos c
        JOIN personas p ON c.id_persona = p.id
        WHERE c.id_equipo = ?
        ORDER BY c.tipo, p.nombre
    """;

        List<Contrato> contratos = new ArrayList<>();

        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement statement = connection.prepareStatement(SQL)
        ) {
            statement.setString(1, equipoId);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Persona persona = Persona.builder()
                            .withId(resultSet.getString("id_persona"))
                            .withNombre(resultSet.getString("nombre"))
                            .withNacionalidad(resultSet.getString("nacionalidad"))
                            .withFechaNacimiento(resultSet.getDate("fecha_nacimiento") != null ?
                                    resultSet.getDate("fecha_nacimiento").toLocalDate() : null)
                            .withFoto(resultSet.getString("foto"))
                            .build();

                    Contrato contrato = Contrato.builder()
                            .withId(resultSet.getString("id"))
                            .withIdPersona(resultSet.getString("id_persona"))
                            .withIdEquipo(resultSet.getString("id_equipo"))
                            .withTipo(Tipo.valueOf(resultSet.getString("tipo")))
                            .withPosicion(resultSet.getString("posicion"))
                            .build();

                    contratos.add(contrato);
                }
            }

            return contratos;

        } catch (SQLException sqlException) {
            throw manageException(sqlException);
        }
    }

    private Equipo toEquipo(ResultSet resultSet) throws SQLException
    {
        return Equipo.builder()
                     .withId(resultSet.getString(1))
                     .withNombre(resultSet.getString(2))
                     .withFundacion(resultSet.getDate(3).toLocalDate())
                     .withPresupuesto(resultSet.getDouble(4))
                     .withHistoria(resultSet.getString(5))
                     .withEscudo(resultSet.getString(6))
                     .build();
    }

    private EquipoAppException manageException(SQLException sqlException)
    {
        String message = sqlException.getMessage();

        if (message.contains("NN_EQUIPOS.NOMBRE")) return new FieldRequiredSQLException("nombre");
        else if (message.contains("NN_EQUIPOS.FUNDACION")) return new FieldRequiredSQLException("fundacion");
        else if (message.contains("NN_EQUIPOS.PRESUPUESTO")) return new FieldRequiredSQLException("presupuesto");
        else if (message.contains("CH_EQUIPOS.PRESUPUESTO")) return new FieldBetweenSQLException("presupuesto", "0", "∞");
        else if (message.contains("FK_CONTRATOS_EQUIPOS")) return new EquipoHasContratosSQLException();

        return new SQLEquipoAppException(sqlException);
    }
}
