package es.upsa.dasi.trabajoI_JavierPozo.wsequipos.domain.repository;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

import java.util.List;
import java.util.Optional;

public interface Repository
{
    List<Equipo> getEquipos() throws EquipoAppException;
    Optional<Equipo> getEquipoById(String id) throws EquipoAppException;
    Equipo saveEquipo(Equipo equipo) throws EquipoAppException;
    void deleteEquipoById(String id) throws EquipoAppException;
    void deleteContratosByEquipoId(String equipoId) throws EquipoAppException;
}
