package es.upsa.dasi.trabajoI_JavierPozo.wsequipos.adapters.output.persistence;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Contrato;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

import java.util.List;
import java.util.Optional;

public interface Dao
{
    List<Equipo> findAll() throws EquipoAppException;
    Optional<Equipo> findEquipoById(String id) throws EquipoAppException;
    Equipo insertEquipo(Equipo equipo) throws EquipoAppException;
    Optional<Equipo> updateEquipo(Equipo equipo) throws EquipoAppException;
    void deleteEquipoById(String id) throws EquipoAppException;
    void deleteContratosByEquipoId(String equipoId) throws EquipoAppException;
    List<Contrato> findContratosByEquipo(String equipoId) throws EquipoAppException;
}
