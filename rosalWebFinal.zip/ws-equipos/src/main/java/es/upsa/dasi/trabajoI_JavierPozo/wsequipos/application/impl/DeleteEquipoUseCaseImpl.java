package es.upsa.dasi.trabajoI_JavierPozo.wsequipos.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wsequipos.application.DeleteEquipoUseCase;
import es.upsa.dasi.trabajoI_JavierPozo.wsequipos.domain.repository.Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class DeleteEquipoUseCaseImpl implements DeleteEquipoUseCase
{
    @Inject
    Repository repository;

    @Override
    public void execute(String id) throws EquipoAppException
    {
        repository.deleteContratosByEquipoId(id);

        repository.deleteEquipoById(id);
    }
}
