import { ImageCarousel } from "@/components/image-carousel"
import { VideoShowcase } from "@/components/video-showcase"
import { BookingCalendar } from "@/components/booking-calendar"
import { ContactForm } from "@/components/contact-form"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Wifi, Car, Utensils, Waves, Wind, Thermometer, MapPin, Users, Phone, Mail } from "lucide-react"
import { houseData, galleryPhotos } from "@/lib/house-data"

export default function HomePage() {
  const amenityIcons = {
    "WiFi gratuito": Wifi,
    "Piscina privada": Waves,
    "Jardín con barbacoa": Utensils,
    "Cocina completamente equipada": Utensils,
    "Aire acondicionado": Wind,
    Calefacción: Thermometer,
    "Aparcamiento gratuito": Car,
    "Vistas al río": MapPin,
  }

  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: "url('/photos/fachada-dia-otono.jpg')",
          }}
        >
          <div className="absolute inset-0 bg-black/30"></div>
        </div>

        <div className="absolute top-0 left-0 right-0 z-20 bg-black/20 backdrop-blur-sm">
          <div className="container mx-auto px-4 py-2">
            <div className="flex flex-wrap items-center justify-center gap-3 md:gap-6 text-white text-xs md:text-sm">
              <div className="flex items-center gap-1.5">
                <Phone className="w-3 h-3 md:w-4 md:h-4" />
                <span>{houseData.phone}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Mail className="w-3 h-3 md:w-4 md:h-4" />
                <span>{houseData.email}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3 h-3 md:w-4 md:h-4" />
                <span>{houseData.location}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="relative z-10 text-center text-white px-4">
          <h1 className="text-5xl md:text-7xl font-bold mb-6">{houseData.name}</h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">{houseData.description}</p>
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <Badge variant="secondary" className="text-lg px-4 py-2">
              <Users className="w-5 h-5 mr-2" />
              Hasta {houseData.capacity} huéspedes
            </Badge>
            <Badge variant="secondary" className="text-lg px-4 py-2">
              <MapPin className="w-5 h-5 mr-2" />
              Rosal, Galicia
            </Badge>
          </div>
          <a
            href="#reservas"
            className="inline-block bg-orange-600 hover:bg-orange-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
          >
            Reservar Ahora
          </a>
        </div>
      </section>

      {/* Video Showcase Section */}
      <VideoShowcase />

      {/* Gallery Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Galería de Fotos</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Descubre todos los rincones de nuestra hermosa casa rural</p>
          </div>

          <div className="max-w-4xl mx-auto">
            <ImageCarousel images={galleryPhotos} />
          </div>
        </div>
      </section>

      {/* Amenities Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Servicios y Comodidades</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Todo lo que necesitas para una estancia perfecta</p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {houseData.amenities.map((amenity, index) => {
                const IconComponent = amenityIcons[amenity as keyof typeof amenityIcons] || MapPin
                return (
                  <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <IconComponent className="w-8 h-8 text-orange-600 mx-auto mb-3" />
                      <p className="text-sm font-medium text-gray-900">{amenity}</p>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Booking Section */}
      <section id="reservas">
        <BookingCalendar />
      </section>

      {/* Contact Section */}
      <ContactForm />
    </main>
  )
}
