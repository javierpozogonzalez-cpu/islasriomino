import { type NextRequest, NextResponse } from "next/server"
import { isDateOccupied, isRangeAvailable } from "@/lib/database"

// GET - Verificar disponibilidad
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const fechaInicio = searchParams.get("fechaInicio")
    const fechaFin = searchParams.get("fechaFin")

    if (!fechaInicio || !fechaFin) {
      return NextResponse.json({ success: false, message: "Se requieren fechas de inicio y fin" }, { status: 400 })
    }

    const inicio = new Date(fechaInicio)
    const fin = new Date(fechaFin)

    const disponible = isRangeAvailable(inicio, fin)

    return NextResponse.json({
      success: true,
      disponible,
      message: disponible ? "Fechas disponibles" : "Fechas no disponibles",
    })
  } catch (error) {
    return NextResponse.json({ success: false, message: "Error al verificar disponibilidad" }, { status: 500 })
  }
}

// POST - Verificar múltiples fechas
export async function POST(request: NextRequest) {
  try {
    const { fechas } = await request.json()

    if (!Array.isArray(fechas)) {
      return NextResponse.json({ success: false, message: "Se requiere un array de fechas" }, { status: 400 })
    }

    const resultado = fechas.map((fecha) => ({
      fecha,
      ocupada: isDateOccupied(new Date(fecha)),
    }))

    return NextResponse.json({
      success: true,
      data: resultado,
    })
  } catch (error) {
    return NextResponse.json({ success: false, message: "Error al verificar fechas" }, { status: 500 })
  }
}
