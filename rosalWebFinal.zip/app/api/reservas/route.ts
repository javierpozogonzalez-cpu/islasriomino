import { type NextRequest, NextResponse } from "next/server"
import { createReservation, getReservations, isRangeAvailable } from "@/lib/database"
import { getPriceForDate } from "@/lib/house-data"

// GET - Obtener todas las reservas
export async function GET() {
  try {
    const reservas = getReservations()
    return NextResponse.json({ success: true, data: reservas })
  } catch (error) {
    return NextResponse.json({ success: false, message: "Error al obtener reservas" }, { status: 500 })
  }
}

// POST - Crear nueva reserva
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { nombre, email, telefono, fechaCheckin, fechaCheckout, numHuespedes, mensaje } = body

    // Validaciones básicas
    if (!nombre || !email || !fechaCheckin || !fechaCheckout || !numHuespedes) {
      return NextResponse.json({ success: false, message: "Faltan campos obligatorios" }, { status: 400 })
    }

    const checkinDate = new Date(fechaCheckin)
    const checkoutDate = new Date(fechaCheckout)

    // Validar fechas
    if (checkinDate >= checkoutDate) {
      return NextResponse.json(
        { success: false, message: "La fecha de checkout debe ser posterior al checkin" },
        { status: 400 },
      )
    }

    if (checkinDate < new Date()) {
      return NextResponse.json(
        { success: false, message: "No se pueden hacer reservas en fechas pasadas" },
        { status: 400 },
      )
    }

    // Verificar disponibilidad
    if (!isRangeAvailable(checkinDate, checkoutDate)) {
      return NextResponse.json(
        { success: false, message: "Las fechas seleccionadas no están disponibles" },
        { status: 409 },
      )
    }

    // Calcular precio total
    let precioTotal = 0
    const currentDate = new Date(checkinDate)

    while (currentDate < checkoutDate) {
      precioTotal += getPriceForDate(currentDate)
      currentDate.setDate(currentDate.getDate() + 1)
    }

    // Añadir tasa de limpieza
    precioTotal += 50 // Tasa de limpieza fija

    // Crear reserva
    const resultado = await createReservation({
      nombre,
      email,
      telefono,
      fechaCheckin: checkinDate,
      fechaCheckout: checkoutDate,
      numHuespedes: Number.parseInt(numHuespedes),
      precioTotal,
      estado: "pendiente",
      mensaje,
    })

    if (resultado.success) {
      return NextResponse.json({
        success: true,
        message: "Reserva creada exitosamente",
        data: { reservaId: resultado.reservaId, precioTotal },
      })
    } else {
      return NextResponse.json({ success: false, message: resultado.message }, { status: 409 })
    }
  } catch (error) {
    console.error("Error al crear reserva:", error)
    return NextResponse.json({ success: false, message: "Error interno del servidor" }, { status: 500 })
  }
}
