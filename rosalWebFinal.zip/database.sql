-- LIMPIEZA
DROP SEQUENCE seq_equipos;
DROP SEQUENCE seq_personas;
DROP SEQUENCE seq_contratos;
DROP TABLE contratos;
DROP TABLE personas;
DROP TABLE equipos;

-- CREACIÓN DE TABLAS
CREATE TABLE EQUIPOS (
                         ID            VARCHAR(9),
                         NOMBRE        VARCHAR(100),
                         FUNDACION     DATE,
                         PRESUPUESTO   NUMERIC(12,2),
                         HISTORIA      VARCHAR(400),
                         ESCUDO        VARCHAR(500),
                         CONSTRAINT "PK_EQUIPOS" PRIMARY KEY (ID),
                         CONSTRAINT "NN_EQUIPOS.NOMBRE" CHECK (NOMBRE IS NOT NULL),
                         CONSTRAINT "NN_EQUIPOS.FUNDACION" CHECK (FUNDACION IS NOT NULL),
                         CONSTRAINT "NN_EQUIPOS.PRESUPUESTO" CHECK (PRESUPUESTO IS NOT NULL),
                         CONSTRAINT "CH_EQUIPOS.PRESUPUESTO" CHECK (PRESUPUESTO > 0)
);

CREATE TABLE PERSONAS (
                          ID               VARCHAR(9),
                          NOMBRE           VARCHAR(100),
                          NACIONALIDAD     VARCHAR(50),
                          FECHA_NACIMIENTO DATE,
                          FOTO             VARCHAR(500),
                          CONSTRAINT "PK_PERSONAS" PRIMARY KEY (ID),
                          CONSTRAINT "NN_PERSONAS.NOMBRE" CHECK (NOMBRE IS NOT NULL),
                          CONSTRAINT "NN_PERSONAS.NACIONALIDAD" CHECK (NACIONALIDAD IS NOT NULL),
                          CONSTRAINT "NN_PERSONAS.FECHA_NACIMIENTO" CHECK (FECHA_NACIMIENTO IS NOT NULL)
);

CREATE TABLE CONTRATOS (
                           ID               VARCHAR(6),
                           ID_PERSONA       VARCHAR(9),
                           ID_EQUIPO        VARCHAR(9),
                           TIPO             VARCHAR(20),
                           POSICION         VARCHAR(100),
                           CONSTRAINT "PK_CONTRATOS" PRIMARY KEY (ID),
                           CONSTRAINT "FK_CONTRATOS_EQUIPOS" FOREIGN KEY (ID_EQUIPO) REFERENCES EQUIPOS(ID),
                           CONSTRAINT "FK_CONTRATOS_PERSONAS" FOREIGN KEY (ID_PERSONA) REFERENCES PERSONAS(ID),
                           CONSTRAINT "NN_CONTRATOS_ID_PERSONA" CHECK (ID_PERSONA IS NOT NULL),
                           CONSTRAINT "NN_CONTRATOS_ID_EQUIPO" CHECK (ID_EQUIPO IS NOT NULL),
                           CONSTRAINT "ENM_CONTRATOS.TIPO" CHECK (TIPO IN ('ENTRENADOR', 'JUGADOR')),
                           CONSTRAINT "NN_CONTRATOS_TIPO" CHECK (TIPO IS NOT NULL)
);

-- SECUENCIAS
CREATE SEQUENCE seq_equipos   START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 999999998;
CREATE SEQUENCE seq_personas  START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 999999998;
CREATE SEQUENCE seq_contratos START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 999998;

-- EQUIPOS (fotos funcionales)
INSERT INTO EQUIPOS VALUES
                        ('eq0000001', 'Real Madrid CF', '1902-10-10', 850000000.00, 'El Real Madrid Club de Fútbol, más conocido como Real Madrid, es una entidad polideportiva con sede en Madrid, España.', 'https://upload.wikimedia.org/wikipedia/en/thumb/5/56/Real_Madrid_CF.svg/1024px-Real_Madrid_CF.svg.png'),
                        ('eq0000002', 'FC Barcelona', '1899-01-01', 800000000.00, 'El Fútbol Club Barcelona, conocido como Barça, es una entidad polideportiva de Barcelona, España.', 'https://upload.wikimedia.org/wikipedia/en/thumb/4/47/FC_Barcelona_%28crest%29.svg/1280px-FC_Barcelona_%28crest%29.svg.png'),
                        ('eq0000003', 'Atlético de Madrid', '1903-04-26', 400000000.00, 'El Club Atlético de Madrid es un club de fútbol de la ciudad de Madrid.', 'https://upload.wikimedia.org/wikipedia/en/thumb/f/f9/Atletico_Madrid_Logo_2024.svg/1024px-Atletico_Madrid_Logo_2024.svg.png'),
                        ('eq0000004', 'Sevilla FC', '1890-03-03', 200000000.00, 'El Sevilla FC es un club de fútbol de Sevilla, Andalucía.', 'https://upload.wikimedia.org/wikipedia/en/thumb/3/3b/Sevilla_FC_logo.svg/1024px-Sevilla_FC_logo.svg.png'),
                        ('eq0000005', 'Valencia CF', '1919-04-04', 180000000.00, 'El Valencia CF es un club de fútbol de Valencia, España.', 'https://upload.wikimedia.org/wikipedia/en/thumb/c/ce/Valenciacf.svg/1024px-Valenciacf.svg.png'),
                        ('eq0000006', 'Celta de Vigo', '1923-08-23', 60000000.00, 'El RC Celta de Vigo es un club de fútbol gallego fundado en agosto de 1923', 'https://upload.wikimedia.org/wikipedia/en/thumb/1/12/RC_Celta_de_Vigo_logo.svg/800px-RC_Celta_de_Vigo_logo.svg.png');

-- ENTRENADORES para todos los equipos
INSERT INTO PERSONAS VALUES
                         ('pr0000001', 'Carlo Ancelotti', 'Italia', '1959-06-10', 'https://upload.wikimedia.org/wikipedia/commons/a/a9/Carlo_Ancelotti_2016_%28cropped%29.jpg'),
                         ('pr0000002', 'Hansi Flick', 'Alemania', '1980-01-25', 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/04/2022_Hansi_Flick_%28cropped%29.jpg/1024px-2022_Hansi_Flick_%28cropped%29.jpg'),
                         ('pr0000003', 'Diego Simeone', 'Argentina', '1970-04-28', 'https://upload.wikimedia.org/wikipedia/commons/1/1d/Diego_Simeone.jpg'),
                         ('pr0000021', 'Joaquin Caparros', 'España', '1961-03-14', 'https://upload.wikimedia.org/wikipedia/commons/1/17/Joaqu%C3%ADn_Caparr%C3%B3s_2012.jpg'),
                         ('pr0000022', 'Rubén Baraja', 'España', '1975-07-11', 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Rub%C3%A9n_Baraja_01_%28cropped%29.jpg/1024px-Rub%C3%A9n_Baraja_01_%28cropped%29.jpg'),
                         ('pr0000023', 'Claudio Giraldez', 'España', '1983-04-16', 'https://img.a.transfermarkt.technology/portrait/big/97955-1713535765.jpg?lm=1');

INSERT INTO PERSONAS VALUES
                         -- Real Madrid
                         ('pr0000004', 'Vinícius Júnior', 'Brasil', '2000-07-12', 'https://assets.laliga.com/squad/2024/t186/p246333/2048x2225/p246333_t186_2024_1_001_000.png'),
                         ('pr0000009', 'Jude Bellingham', 'Inglaterra', '2003-06-29', 'https://assets.laliga.com/squad/2024/t186/p244855/2048x2225/p244855_t186_2024_1_001_000.png'),
                         ('pr0000010', 'Luka Modrić', 'Croacia', '1985-09-09', 'https://assets.laliga.com/squad/2024/t186/p37055/2048x2048/p37055_t186_2024_1_002_000.jpg'),

                         -- FC Barcelona
                         ('pr0000005', 'Robert Lewandowski', 'Polonia', '1988-08-21', 'https://assets.laliga.com/squad/2024/t178/p56764/2048x2048/p56764_t178_2024_1_002_000.jpg'),
                         ('pr0000011', 'Pedri González', 'España', '2002-11-25', 'https://assets.laliga.com/squad/2024/t178/p490541/2048x2048/p490541_t178_2024_1_003_000.png'),
                         ('pr0000012', 'Raphinha', 'Brasil', '1996-12-14', 'https://www.fcbarcelona.com/photo-resources/2024/10/13/266dc5af-16b0-4290-99c5-03d73a48df11/11-Raphinha-M.png?width=624&height=368'),

                         -- Atlético de Madrid
                         ('pr0000006', 'Antoine Griezmann', 'Francia', '1991-03-21', 'https://img.uefa.com/imgml/TP/players/1/2025/cutoff/250019498.webp'),
                         ('pr0000014', 'Koke Resurrección', 'España', '1992-01-08', 'https://assets.laliga.com/squad/2024/t175/p77390/2048x2048/p77390_t175_2024_1_002_000.jpg'),

                         -- Sevilla FC
                         ('pr0000007', 'Jesús Navas', 'España', '1985-11-21', 'https://one-versus-one.com/storage/images/player/5424.png'),
                         ('pr0000016', 'Ivan Rakitić', 'Croacia', '1988-03-10', 'https://www.lapreferente.com/imagenes/jugadores/20202021/77700.png?f=20201115%2000:49:57'),

                         -- Valencia CF
                         ('pr0000008', 'José Gayà', 'España', '1995-05-25', 'https://assets.laliga.com/squad/2024/t191/p132105/2048x2048/p132105_t191_2024_1_002_000.jpg'),
                         ('pr0000017', 'Hugo Duro', 'España', '1999-11-10', 'https://www.valenciacf.com/public/Image/2024/8/1724405808hugoduro_RetratoGrande.png'),
                         ('pr0000018', 'Mouctar Diakhaby', 'Guinea', '1996-12-19', 'https://www.valenciacf.com/public/Image/2024/8/diakhaby_RetratoGrande.png'),

                         -- Celta de Vigo
                         ('pr0000019', 'Iago Aspas', 'España', '1987-08-01', 'https://rccelta.es/app/uploads/2020/05/RC_CELTA_24_25__Iago_Aspas_01-removebg-preview-e1724071291969.png'),
                         ('pr0000020', 'Fran Beltrán', 'España', '1999-02-03', 'https://rccelta.es/app/uploads/2020/05/RC_CELTA_24_25__Fran_Beltran_01-removebg-preview-e1724068944747.png');


-- CONTRATOS ENTRENADORES
INSERT INTO CONTRATOS VALUES
                          (nextval('seq_contratos'), 'pr0000001', 'eq0000001', 'ENTRENADOR', NULL),
                          (nextval('seq_contratos'), 'pr0000002', 'eq0000002', 'ENTRENADOR', NULL),
                          (nextval('seq_contratos'), 'pr0000003', 'eq0000003', 'ENTRENADOR', NULL),
                          (nextval('seq_contratos'), 'pr0000021', 'eq0000004', 'ENTRENADOR', NULL),
                          (nextval('seq_contratos'), 'pr0000022', 'eq0000005', 'ENTRENADOR', NULL),
                          (nextval('seq_contratos'), 'pr0000023', 'eq0000006', 'ENTRENADOR', NULL);

-- CONTRATOS JUGADORES
INSERT INTO CONTRATOS VALUES
                          (nextval('seq_contratos'), 'pr0000004', 'eq0000001', 'JUGADOR', 'Extremo Izquierdo'),
                          (nextval('seq_contratos'), 'pr0000009', 'eq0000001', 'JUGADOR', 'Centrocampista'),
                          (nextval('seq_contratos'), 'pr0000010', 'eq0000001', 'JUGADOR', 'Centrocampista'),

                          (nextval('seq_contratos'), 'pr0000005', 'eq0000002', 'JUGADOR', 'Delantero Centro'),
                          (nextval('seq_contratos'), 'pr0000011', 'eq0000002', 'JUGADOR', 'Centrocampista'),
                          (nextval('seq_contratos'), 'pr0000012', 'eq0000002', 'JUGADOR', 'Extremo Derecho'),

                          (nextval('seq_contratos'), 'pr0000006', 'eq0000003', 'JUGADOR', 'Delantero'),
                          (nextval('seq_contratos'), 'pr0000014', 'eq0000003', 'JUGADOR', 'Centrocampista'),

                          (nextval('seq_contratos'), 'pr0000007', 'eq0000004', 'JUGADOR', 'Lateral Derecho'),
                          (nextval('seq_contratos'), 'pr0000016', 'eq0000004', 'JUGADOR', 'Centrocampista'),

                          (nextval('seq_contratos'), 'pr0000008', 'eq0000005', 'JUGADOR', 'Lateral Izquierdo'),
                          (nextval('seq_contratos'), 'pr0000017', 'eq0000005', 'JUGADOR', 'Delantero'),
                          (nextval('seq_contratos'), 'pr0000018', 'eq0000005', 'JUGADOR', 'Defensa Central'),

                          (nextval('seq_contratos'), 'pr0000019', 'eq0000006', 'JUGADOR', 'Delantero'),
                          (nextval('seq_contratos'), 'pr0000020', 'eq0000006', 'JUGADOR', 'Centrocampista');


COMMIT;
