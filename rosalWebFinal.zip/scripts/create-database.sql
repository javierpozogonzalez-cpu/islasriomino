-- Crear base de datos para el sistema de reservas
CREATE DATABASE IF NOT EXISTS casa_rural_reservas;
USE casa_rural_reservas;

-- Tabla de reservas
CREATE TABLE reservas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    telefono VARCHAR(20),
    fecha_checkin DATE NOT NULL,
    fecha_checkout DATE NOT NULL,
    num_huespedes INT NOT NULL,
    precio_total DECIMAL(10,2) NOT NULL,
    estado ENUM('pendiente', 'confirmada', 'cancelada') DEFAULT 'pendiente',
    mensaje TEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Índices para mejorar rendimiento
    INDEX idx_fechas (fecha_checkin, fecha_checkout),
    INDEX idx_estado (estado),
    INDEX idx_email (email),
    INDEX idx_fecha_creacion (fecha_creacion)
);

-- Tabla de fechas bloqueadas (para mantenimiento, etc.)
CREATE TABLE fechas_bloqueadas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NOT NULL,
    motivo VARCHAR(255) NOT NULL,
    activo BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_fechas_bloqueadas (fecha_inicio, fecha_fin, activo)
);

-- Tabla de configuración de la casa
CREATE TABLE configuracion_casa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    capacidad_maxima INT NOT NULL,
    precio_temporada_baja DECIMAL(8,2) NOT NULL,
    precio_temporada_media DECIMAL(8,2) NOT NULL,
    precio_temporada_alta DECIMAL(8,2) NOT NULL,
    tasa_limpieza DECIMAL(8,2) DEFAULT 50.00,
    telefono VARCHAR(20),
    email VARCHAR(100),
    whatsapp VARCHAR(20),
    activo BOOLEAN DEFAULT TRUE,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insertar configuración inicial
INSERT INTO configuracion_casa (
    nombre, 
    descripcion, 
    capacidad_maxima, 
    precio_temporada_baja, 
    precio_temporada_media, 
    precio_temporada_alta,
    tasa_limpieza,
    telefono, 
    email, 
    whatsapp
) VALUES (
    'Casa Islas Rio Miño',
    'Una hermosa casa rural junto al río Miño, perfecta para desconectar y disfrutar de la naturaleza.',
    8,
    120.00,
    150.00,
    180.00,
    50.00,
    '+34 123 456 789',
    'info@casaislasriomino.com',
    '34123456789'
);

-- Insertar algunas reservas de ejemplo
INSERT INTO reservas (nombre, email, telefono, fecha_checkin, fecha_checkout, num_huespedes, precio_total, estado, mensaje) VALUES
('Juan Pérez', 'juan@email.com', '+34123456789', '2024-02-15', '2024-02-18', 4, 450.00, 'confirmada', 'Reserva para familia con niños'),
('María García', 'maria@email.com', '+34987654321', '2024-03-20', '2024-03-25', 6, 750.00, 'confirmada', 'Celebración aniversario'),
('Carlos López', 'carlos@email.com', '+34555666777', '2024-04-10', '2024-04-14', 2, 600.00, 'pendiente', 'Luna de miel');

-- Insertar fechas bloqueadas de ejemplo
INSERT INTO fechas_bloqueadas (fecha_inicio, fecha_fin, motivo) VALUES
('2024-01-15', '2024-01-20', 'Mantenimiento piscina'),
('2024-12-24', '2024-12-26', 'Vacaciones navideñas');

-- Crear vista para consultas frecuentes
CREATE VIEW vista_reservas_activas AS
SELECT 
    r.id,
    r.nombre,
    r.email,
    r.telefono,
    r.fecha_checkin,
    r.fecha_checkout,
    r.num_huespedes,
    r.precio_total,
    r.estado,
    r.mensaje,
    r.fecha_creacion,
    DATEDIFF(r.fecha_checkout, r.fecha_checkin) as noches
FROM reservas r
WHERE r.estado IN ('pendiente', 'confirmada')
ORDER BY r.fecha_checkin;

-- Función para verificar disponibilidad
DELIMITER //
CREATE FUNCTION verificar_disponibilidad(fecha_inicio DATE, fecha_fin DATE) 
RETURNS BOOLEAN
READS SQL DATA
DETERMINISTIC
BEGIN
    DECLARE conflictos INT DEFAULT 0;
    
    -- Verificar reservas confirmadas
    SELECT COUNT(*) INTO conflictos
    FROM reservas 
    WHERE estado = 'confirmada' 
    AND (
        (fecha_checkin <= fecha_inicio AND fecha_checkout > fecha_inicio) OR
        (fecha_checkin < fecha_fin AND fecha_checkout >= fecha_fin) OR
        (fecha_checkin >= fecha_inicio AND fecha_checkout <= fecha_fin)
    );
    
    -- Si hay conflictos con reservas, no está disponible
    IF conflictos > 0 THEN
        RETURN FALSE;
    END IF;
    
    -- Verificar fechas bloqueadas
    SELECT COUNT(*) INTO conflictos
    FROM fechas_bloqueadas 
    WHERE activo = TRUE 
    AND (
        (fecha_inicio <= fecha_inicio AND fecha_fin > fecha_inicio) OR
        (fecha_inicio < fecha_fin AND fecha_fin >= fecha_fin) OR
        (fecha_inicio >= fecha_inicio AND fecha_fin <= fecha_fin)
    );
    
    -- Si hay conflictos con bloqueos, no está disponible
    IF conflictos > 0 THEN
        RETURN FALSE;
    END IF;
    
    RETURN TRUE;
END //
DELIMITER ;
