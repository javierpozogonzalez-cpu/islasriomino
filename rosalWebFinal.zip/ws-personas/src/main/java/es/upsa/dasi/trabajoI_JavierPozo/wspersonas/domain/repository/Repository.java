package es.upsa.dasi.trabajoI_JavierPozo.wspersonas.domain.repository;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

import java.util.List;
import java.util.Optional;

public interface Repository
{
    List<Persona> getPersonas() throws EquipoAppException;
    Optional<Persona> getPersonaById(String id) throws EquipoAppException;
    Persona savePersona(Persona persona) throws EquipoAppException;
    void deletePersona(String id) throws EquipoAppException;
}
