package es.upsa.dasi.trabajoI_JavierPozo.wspersonas.domain.repository.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.PersonaNotFoundAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wspersonas.adapters.output.persistence.Dao;
import es.upsa.dasi.trabajoI_JavierPozo.wspersonas.domain.repository.Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.List;
import java.util.Optional;

@ApplicationScoped
public class RepositoryImpl implements Repository
{
    @Inject
    Dao dao;

    @Override
    public List<Persona> getPersonas() throws EquipoAppException
    {
        return dao.findAll();
    }

    @Override
    public Optional<Persona> getPersonaById(String id) throws EquipoAppException
    {
        return dao.findPersonaById(id);
    }

    @Override
    public Persona savePersona(Persona persona) throws EquipoAppException
    {
        return (persona.getId() == null) ? dao.insertPersona(persona) : dao.updatePersona(persona)
                                                                           .orElseThrow(() -> new PersonaNotFoundAppException());
    }

    @Override
    public void deletePersona(String id) throws EquipoAppException
    {
        dao.removePersonaById(id);
    }
}
