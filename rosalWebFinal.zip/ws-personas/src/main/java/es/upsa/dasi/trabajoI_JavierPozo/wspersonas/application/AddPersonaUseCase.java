package es.upsa.dasi.trabajoI_JavierPozo.wspersonas.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

public interface AddPersonaUseCase
{
    Persona execute(Persona persona) throws EquipoAppException;
}
