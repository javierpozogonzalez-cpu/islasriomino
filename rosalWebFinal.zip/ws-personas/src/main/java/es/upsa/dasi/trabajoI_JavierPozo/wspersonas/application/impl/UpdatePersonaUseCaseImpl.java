package es.upsa.dasi.trabajoI_JavierPozo.wspersonas.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wspersonas.application.UpdatePersonaUseCase;
import es.upsa.dasi.trabajoI_JavierPozo.wspersonas.domain.repository.Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class UpdatePersonaUseCaseImpl implements UpdatePersonaUseCase
{
    @Inject
    Repository repository;

    @Override
    public Persona execute(Persona persona) throws EquipoAppException
    {
        return repository.savePersona(persona);
    }
}
