package es.upsa.dasi.trabajoI_JavierPozo.wspersonas.infrastructure.persistence;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.PersonaNotFoundAppException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.SQLEquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wspersonas.adapters.output.persistence.Dao;
import es.upsa.dasi.trabajoI_JavierPozo.wspersonas.domain.exceptions.FieldRequiredSQLException;
import es.upsa.dasi.trabajoI_JavierPozo.wspersonas.domain.exceptions.PersonaHasContratosSQLException;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@ApplicationScoped
public class DaoImpl implements Dao
{
    @Inject
    DataSource dataSource;

    @Override
    public List<Persona> findAll() throws EquipoAppException
    {
        final String SQL = """
                           SELECT p.id, p.nombre, p.nacionalidad, p.fecha_nacimiento, p.foto
                             FROM personas p
                           """;
        List<Persona> personas = new ArrayList<>();

        try(
                Connection connection = dataSource.getConnection();
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(SQL);
           )
        {
            while (resultSet.next())
            {
                personas.add(toPersona(resultSet));
            }

            return personas;

        } catch (SQLException sqlException)
        {
            throw manageException(sqlException);
        }
    }

    @Override
    public Optional<Persona> findPersonaById(String id) throws EquipoAppException
    {
        final String SQL = """
                           SELECT p.id, p.nombre, p.nacionalidad, p.fecha_nacimiento, p.foto
                             FROM personas p
                            WHERE p.id = ? 
                           """;

        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SQL);
            )
        {
            preparedStatement.setString(1, id);

            try (ResultSet resultSet = preparedStatement.executeQuery())
            {
                return (!resultSet.next()) ? Optional.empty() : Optional.of(toPersona(resultSet));
            }

        } catch (SQLException sqlException)
        {
            throw manageException(sqlException);
        }
    }

    @Override
    public Persona insertPersona(Persona persona) throws EquipoAppException
    {
        final String SQL = """
                           INSERT INTO personas(id,                      nombre, nacionalidad, fecha_nacimiento, foto)
                                        VALUES (nextval('seq_personas'), ?,      ?,            ?,                ?   )
                           """;
        final String[] fields = {"id"};

        try(
                Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SQL, fields)
           )
        {
            preparedStatement.setString(1, persona.getNombre());
            preparedStatement.setString(2, persona.getNacionalidad());
            preparedStatement.setDate(3, Date.valueOf(persona.getFechaNacimiento()));
            preparedStatement.setString(4, persona.getFoto());

            preparedStatement.executeUpdate();

            try (ResultSet resultSet = preparedStatement.getGeneratedKeys())
            {
                resultSet.next();
                String id = resultSet.getString(1);

                return persona.withId(id);
            }

        } catch (SQLException sqlException)
          {
              throw manageException(sqlException);
          }
    }

    @Override
    public Optional<Persona> updatePersona(Persona persona) throws EquipoAppException
    {
        final String SQL = """
                           UPDATE personas
                             SET nombre = ?,
                                 nacionalidad = ?,
                                 fecha_nacimiento = ?,
                                 foto = ?
                            WHERE id = ?
                           """;

        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SQL);
            )
        {
            preparedStatement.setString(1, persona.getNombre());
            preparedStatement.setString(2, persona.getNacionalidad());
            preparedStatement.setDate(3, Date.valueOf(persona.getFechaNacimiento()));
            preparedStatement.setString(4, persona.getFoto());
            preparedStatement.setString(5, persona.getId());

            int count = preparedStatement.executeUpdate();

            return (count == 0) ? Optional.empty() : Optional.of(persona);

        } catch (SQLException sqlException)
        {
            throw manageException(sqlException);
        }
    }

    @Override
    public void removePersonaById(String id) throws EquipoAppException
    {
        final String SQL = """
                           DELETE 
                             FROM personas
                            WHERE id = ? 
                           """;

        try (
                Connection connection = dataSource.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(SQL);
            )
        {
            preparedStatement.setString(1, id);

            int count = preparedStatement.executeUpdate();

            if (count == 0) throw new PersonaNotFoundAppException();

        } catch (SQLException sqlException)
          {
            throw manageException(sqlException);
          }
    }

    private Persona toPersona(ResultSet resultSet) throws SQLException
    {
        return Persona.builder()
                      .withId(resultSet.getString(1))
                      .withNombre(resultSet.getString(2))
                      .withNacionalidad(resultSet.getString(3))
                      .withFechaNacimiento(resultSet.getDate(4).toLocalDate())
                      .withFoto(resultSet.getString(5))
                      .build();
    }

    private EquipoAppException manageException(SQLException sqlException)
    {
        String message = sqlException.getMessage();

        if (message.contains("NN_PERSONAS.NOMBRE")) return new FieldRequiredSQLException("nombre");
        if (message.contains("NN_PERSONAS.NACIONALIDAD")) return new FieldRequiredSQLException("nacionalidad");
        if (message.contains("FK_CONTRATOS_PERSONA")) return new PersonaHasContratosSQLException();

        return new SQLEquipoAppException(sqlException);
    }
}
