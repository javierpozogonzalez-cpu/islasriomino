package es.upsa.dasi.trabajoI_JavierPozo.wspersonas.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wspersonas.application.DeletePersonaUseCase;
import es.upsa.dasi.trabajoI_JavierPozo.wspersonas.domain.repository.Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class DeletePersonaUseCaseImpl implements DeletePersonaUseCase
{
    @Inject
    Repository repository;

    @Override
    public void execute(String id) throws EquipoAppException
    {
        repository.deletePersona(id);
    }
}
