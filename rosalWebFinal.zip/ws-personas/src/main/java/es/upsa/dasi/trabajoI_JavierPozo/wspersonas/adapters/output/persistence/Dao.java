package es.upsa.dasi.trabajoI_JavierPozo.wspersonas.adapters.output.persistence;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

import java.util.List;
import java.util.Optional;

public interface Dao
{
    List<Persona> findAll() throws EquipoAppException;
    Optional<Persona> findPersonaById(String id) throws EquipoAppException;
    Persona insertPersona(Persona persona) throws EquipoAppException;
    Optional<Persona> updatePersona(Persona persona) throws EquipoAppException;
    void removePersonaById(String id) throws EquipoAppException;
}
