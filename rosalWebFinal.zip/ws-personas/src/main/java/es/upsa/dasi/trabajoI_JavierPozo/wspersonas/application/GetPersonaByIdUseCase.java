package es.upsa.dasi.trabajoI_JavierPozo.wspersonas.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

import java.util.Optional;

public interface GetPersonaByIdUseCase
{
    Optional<Persona> execute(String id) throws EquipoAppException;
}
