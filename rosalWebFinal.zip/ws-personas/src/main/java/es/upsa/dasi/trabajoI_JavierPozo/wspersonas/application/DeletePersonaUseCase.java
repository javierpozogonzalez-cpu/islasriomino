package es.upsa.dasi.trabajoI_JavierPozo.wspersonas.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

public interface DeletePersonaUseCase
{
    void execute(String id) throws EquipoAppException;
}
