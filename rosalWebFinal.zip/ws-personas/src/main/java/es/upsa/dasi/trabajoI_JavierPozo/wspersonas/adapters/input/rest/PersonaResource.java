package es.upsa.dasi.trabajoI_JavierPozo.wspersonas.adapters.input.rest;

import es.upsa.dasi.trabajoI_JavierPozo.domain.dtos.PersonaDto;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Equipo;
import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoNotFoundException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.PersonaNotFoundAppException;
import es.upsa.dasi.trabajoI_JavierPozo.domain.mappers.Mappers;
import es.upsa.dasi.trabajoI_JavierPozo.wspersonas.application.*;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;

@ApplicationScoped
@Path("/personas")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class PersonaResource
{
    @Inject
    GetPersonasUseCase getPersonasUseCase;

    @Inject
    GetPersonaByIdUseCase getPersonaByIdUseCase;

    @Inject
    AddPersonaUseCase addPersonaUseCase;

    @Inject
    UpdatePersonaUseCase updatePersonaUseCase;

    @Inject
    DeletePersonaUseCase deletePersonaUseCase;

    @GET
    public Response getPersonas() throws EquipoAppException
    {
        List<Persona> personas = getPersonasUseCase.execute();

        return Response.ok()
                       .entity(new GenericEntity<List <Persona>> (personas) {})
                       .build();
    }

    @GET
    @Path("/{id}")
    public Response getPersonaById(@PathParam("id") String id) throws EquipoAppException
    {
        Optional<Persona> optPersona = getPersonaByIdUseCase.execute(id);

        return optPersona.map(persona -> Response.ok().entity(persona).build())
                         .orElseThrow(() -> new PersonaNotFoundAppException());
    }

    @POST
    public Response addPersona(PersonaDto personaDto, @Context UriInfo uriInfo) throws EquipoAppException
    {
        Persona persona = Mappers.toPersona(personaDto);
        Persona insertedPersona = addPersonaUseCase.execute(persona);

        return Response.created(createPersonaURI(uriInfo, insertedPersona))
                       .entity(insertedPersona)
                       .build();
    }

    @PUT
    @Path("/{id}")
    public Response updatePersona(@PathParam("id") String id, PersonaDto personaDto) throws EquipoAppException
    {
        Persona persona = Mappers.toPersona(personaDto)
                                 .withId(id);

        Persona updatedPersona = updatePersonaUseCase.execute(persona);

        return Response.ok()
                       .entity(updatedPersona)
                       .build();
    }

    @DELETE
    @Path("/{id}")
    public Response deletePersona(@PathParam("id") String id) throws EquipoAppException
    {
        deletePersonaUseCase.execute(id);

        return Response.noContent()
                       .build();
    }

    private URI createPersonaURI(UriInfo uriInfo, Persona persona)
    {
        return uriInfo.getBaseUriBuilder()
                      .path("/personas/{id}")
                      .resolveTemplate("id", persona.getId())
                      .build();
    }
}
