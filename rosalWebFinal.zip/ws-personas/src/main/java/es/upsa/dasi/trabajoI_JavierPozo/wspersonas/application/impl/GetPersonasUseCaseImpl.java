package es.upsa.dasi.trabajoI_JavierPozo.wspersonas.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wspersonas.application.GetPersonasUseCase;
import es.upsa.dasi.trabajoI_JavierPozo.wspersonas.domain.repository.Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.List;

@ApplicationScoped
public class GetPersonasUseCaseImpl implements GetPersonasUseCase
{
    @Inject
    Repository repository;


    @Override
    public List<Persona> execute() throws EquipoAppException
    {
        return repository.getPersonas();
    }
}
