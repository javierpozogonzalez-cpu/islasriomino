package es.upsa.dasi.trabajoI_JavierPozo.wspersonas.application;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

import java.util.List;

public interface GetPersonasUseCase
{
    List<Persona> execute() throws EquipoAppException;
}
