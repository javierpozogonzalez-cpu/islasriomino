package es.upsa.dasi.trabajoI_JavierPozo.wspersonas.domain.exceptions;

import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;

public class PersonaHasContratosSQLException extends EquipoAppException
{
    public PersonaHasContratosSQLException()
    {
        super("No se puede eliminar la persona porque tiene contratos asociados");
    }
}
