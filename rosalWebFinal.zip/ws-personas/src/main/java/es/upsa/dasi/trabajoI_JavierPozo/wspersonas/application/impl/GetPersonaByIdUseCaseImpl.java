package es.upsa.dasi.trabajoI_JavierPozo.wspersonas.application.impl;

import es.upsa.dasi.trabajoI_JavierPozo.domain.entities.Persona;
import es.upsa.dasi.trabajoI_JavierPozo.domain.exceptions.EquipoAppException;
import es.upsa.dasi.trabajoI_JavierPozo.wspersonas.application.GetPersonaByIdUseCase;
import es.upsa.dasi.trabajoI_JavierPozo.wspersonas.domain.repository.Repository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.Optional;

@ApplicationScoped
public class GetPersonaByIdUseCaseImpl implements GetPersonaByIdUseCase
{
    @Inject
    Repository repository;

    @Override
    public Optional<Persona> execute(String id) throws EquipoAppException
    {
        return repository.getPersonaById(id);
    }
}
